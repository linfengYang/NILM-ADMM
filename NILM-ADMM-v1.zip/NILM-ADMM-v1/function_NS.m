function [result] = function_NS(x_init,Input_parameter)
%FUNCTION_NS �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

%input parameter
P=Input_parameter.P_mid;
state_variable_location=Input_parameter.state_variable_location;
power_variable_location=Input_parameter.power_variable_location;
class_num=Input_parameter.class_num;
T=Input_parameter.T;
P_Sum=Input_parameter.P_total;
always_on_appliance=Input_parameter.alway_on_matri;
State_Limit=Input_parameter.State_Limit;
P_top=Input_parameter.P_top;
P_bottom=Input_parameter.P_bottom; 
f=Input_parameter.f;%objective function
model=Input_parameter.model;
penlty_s=Input_parameter.penlty_s;

if(size(penlty_s,2)<T)
    times=floor(T/size(penlty_s,2));
    num_mod=mod(T,size(penlty_s,2));
    if(times~=1)
        penlty_s=repmat(penlty_s,1,times);
    end
    if(num_mod~=0)
        penlty_s=[penlty_s,penlty_s(:,1:num_mod)];
    end
end

MAX_ITER=3;
state_size_MILP = sum(class_num);
state_variable=reshape(x_init(state_variable_location),T,state_size_MILP);
power_variable=state_variable.*reshape(x_init(power_variable_location),T,state_size_MILP);

index_appliance_MILP=[];
for i=1:length(class_num)
    index_appliance_MILP=[index_appliance_MILP;i*ones(class_num(i),1)];
end

nonAlways_on_index=find(always_on_appliance==0);
nonAlways_on_power_index=[];
for i=1:length(nonAlways_on_index)
nonAlways_on_power_index=[nonAlways_on_power_index;find(index_appliance_MILP==nonAlways_on_index(i))];
end
P_min=min(P(nonAlways_on_power_index));
State_Limit_min=min(State_Limit(nonAlways_on_power_index));



%check out of the bound of appliance power
error_window=function_objective_value(f,x_init,T,state_size_MILP,P_Sum,state_variable,power_variable,state_variable',power_variable',1,T);

for i=1:state_size_MILP
    
    On_index=find(state_variable(:,i)==1);
    [index_power]=find(power_variable(On_index,i)>=P_top(i)|power_variable(On_index,i)<=P_bottom(i));
    if(~isempty(index_power))
        power_variable(On_index(index_power),i)=P(i);
    end
    power_variable_temp=power_variable;
    power_variable_temp(:,i)=P(i)*state_variable(:,i);
    error_window_temp=function_objective_value(f,x_init,T,state_size_MILP,P_Sum,state_variable,power_variable,state_variable',power_variable_temp',1,T);
    if(error_window_temp<error_window)
        power_variable=power_variable_temp;
    end
end

power_appliance=state_variable.*power_variable;%
Decompose_data = {};
predict_sum = sparse(T, 1);
for  i= 1:state_size_MILP
    index_i=find(index_appliance_MILP==i);
    decompose =sum(power_appliance(:,index_i),2);
    Decompose_data{i} = decompose;
     predict_sum = predict_sum+Decompose_data{i};
end



error=abs(P_Sum-predict_sum);
tic
%destroy
destroy_location=find(error>P_min);
destroy_location=[destroy_location;T];


difference_power=destroy_location(2:end)-destroy_location(1:end-1);

index_windows_start=0;
index_windows_end=0;
destroy_window=[];
for i=1:length(difference_power)
    if(difference_power(i)==1)
        if(index_windows_start==0)
            index_windows_start=i+1;
        else
            index_windows_end=i+1;
        end
    end
    if(difference_power(i)>6)
        if(index_windows_end~=0)
            if(index_windows_end-index_windows_start>6)
                destroy_window=[destroy_window;destroy_location(index_windows_start),destroy_location(index_windows_end)];
                index_windows_start=0;
                index_windows_end=0;
            else
                index_windows_start=0;
                index_windows_end=0;
            end
        else
            index_windows_start=0;
        end
    end
end
% destroy_window_end=destroy_window_start(2:end)-1;
% destroy_window_start=destroy_window_start+1;
% destroy_window_start=destroy_window_start(1:end-1);
% destroy_window=[destroy_location(destroy_window_start),destroy_location(destroy_window_end)];
% nonAlways_on_appliance_state=state_variable(:,nonAlways_on_power_index);
% nonAlways_on_power_appliance=power_appliance(:,nonAlways_on_power_index);

%sequence
%score
score=[];
for i=1:size(destroy_window,1)
    score=[score,sum(penlty_s(:,destroy_window(i,1):destroy_window(i,2)),2)];
end
[sort_score,sort_index] = sort(score,1);



%repair



%
for i=1:size(destroy_window,1)
    destroy_state=state_variable(destroy_window(i,1):destroy_window(i,2),:)';    
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                destroy_power=repmat(P,1,size(destroy_state,2)).*destroy_state;
    P_sum_window=P_Sum(destroy_window(i,1):destroy_window(i,2));
    error_window=function_objective_value(f,x_init,T,state_size_MILP,P_Sum,state_variable,power_variable,destroy_state,destroy_power,destroy_window(i,1),destroy_window(i,2));
%     error_window=function_objective_value_by_solver(model,x_init,T,state_size_MILP,state_variable,destroy_state,destroy_window(i,1),destroy_window(i,2));
    error_window_init=error_window;
    for iter=1:MAX_ITER   
        
        %����ػ�
        [index_row,index_col]=find(destroy_state==1);

        appliance_index=unique(index_row);
        [sort_score_temple,sort_score_index]=sort(score(appliance_index,i),'descend');
        for j=1:length(appliance_index)
            destroy_state_temp=destroy_state;
            destroy_power_temp=destroy_power;
            if(sum(ismember(nonAlways_on_power_index,appliance_index(sort_score_index(j))))==1)
                destroy_state_temp(appliance_index(sort_score_index(j)),:)=0;
                destroy_power_temp(appliance_index(sort_score_index(j)),:)=0;
                error_window_temp=function_objective_value(f,x_init,T,state_size_MILP,P_Sum,state_variable,power_variable,destroy_state_temp,destroy_power_temp,destroy_window(i,1),destroy_window(i,2));
%                 error_window_temp=function_objective_value_by_solver(model,x_init,T,state_size_MILP,state_variable,destroy_state_temp,destroy_window(i,1),destroy_window(i,2));
                if(error_window_temp<error_window_init)
                    destroy_state_init=destroy_state_temp;
                    destroy_power_init=destroy_power_temp;
                    error_window_init=error_window_temp;
                end
            else
                
                error_window_on_appliance=[];
               [index_On_appliance]=find(index_appliance_MILP==index_appliance_MILP(appliance_index(sort_score_index(j))));
                [index_state]=find(index_On_appliance==appliance_index(sort_score_index(j)));
                if(index_state>1)
                    destroy_state_temp(index_On_appliance(index_state),:)=0;
                    destroy_power_temp(index_On_appliance(index_state),:)=0;
                    for k=index_state-1:1
                        destroy_state_temp(index_On_appliance(k),:)=1;
                        destroy_power_temp(index_On_appliance(k),:)=P(index_On_appliance(k));
                        error_window_temp=function_objective_value(f,x_init,T,state_size_MILP,P_Sum,state_variable,power_variable,destroy_state_temp,destroy_power_temp,destroy_window(i,1),destroy_window(i,2));
%                         error_window_temp=function_objective_value_by_solver(model,x_init,T,state_size_MILP,state_variable,destroy_state_temp,destroy_window(i,1),destroy_window(i,2));
                        if(error_window_temp<error_window_init)
                            destroy_state_init=destroy_state_temp;
                            destroy_power_init=destroy_power_temp;
                            error_window_init=error_window_temp;
                        end
                    end  
                end
            end
        end
        if(error_window_init<error_window)
            destroy_state=destroy_state_init;
            destroy_power=destroy_power_init; 
            error_window=error_window_init;
        end
        [index_error]=find(abs(P_sum_window-sum(destroy_power,1)')>P_min);
        if(isempty(index_error))
            break;
        end

    end
    
    if(mean(abs(P_sum_window-sum(destroy_power,1)'))>P_min)%�������û������ִ���������
        %�������
        for iter=1:MAX_ITER
            i
            iter
            [index_row,index_col]=find(destroy_state==0);            
            appliance_index=unique(index_row);
            [sort_score_temple,sort_score_index]=sort(score(appliance_index,i),'ascend');
            for j=1:length(appliance_index)
                destroy_state_temp=destroy_state;
                destroy_power_temp=destroy_power;
                [index_On_appliance]=find(index_appliance_MILP==index_appliance_MILP(appliance_index(sort_score_index(j))));
                if(length(index_On_appliance)>1)
                    [index_state]=find(index_On_appliance==appliance_index(sort_score_index(j)));
                    index_turnoff_appliance=index_On_appliance;
                    index_turnoff_appliance(index_state)=[];
                    destroy_state_temp(index_turnoff_appliance,:)=0;
                    destroy_power_temp(index_turnoff_appliance,:)=0;
                    destroy_state_temp(appliance_index(sort_score_index(j)),:)=1;
                    destroy_power_temp(appliance_index(sort_score_index(j)),:)=P(index_On_appliance(index_state));                    
                else
                    destroy_state_temp(index_On_appliance,:)=1;
                    destroy_power_temp(index_On_appliance,:)=P(index_On_appliance);
                end
                error_window_temp=function_objective_value(f,x_init,T,state_size_MILP,P_Sum,state_variable,power_variable,destroy_state_temp,destroy_power_temp,destroy_window(i,1),destroy_window(i,2));
%                 error_window_temp=function_objective_value_by_solver(model,x_init,T,state_size_MILP,state_variable,destroy_state_temp,destroy_window(i,1),destroy_window(i,2));
                if(error_window_temp<error_window_init)
                    destroy_state_init=destroy_state_temp;
                    destroy_power_init=destroy_power_temp;
                    error_window_init=error_window_temp;
                end
            end
            if(error_window_init<error_window)
                destroy_state=destroy_state_init;
                destroy_power=destroy_power_init;
                error_window=error_window_init;
            end
            [index_error]=find(abs(P_sum_window-sum(destroy_power,1)')>P_min);
            if(isempty(index_error))
                iter=MAX_ITER+1;
            end
        end
    end
    state_variable(destroy_window(i,1):destroy_window(i,2),:)=destroy_state';
    power_appliance(destroy_window(i,1):destroy_window(i,2),:)=destroy_power';
end
time=toc;
x_init(1:T*state_size_MILP)=reshape(state_variable,T*state_size_MILP,1);
x_init(T*state_size_MILP+1:2*T*state_size_MILP)=reshape(power_appliance,T*state_size_MILP,1);

result.x = x_init;
result.time = time;




end

function [objective_value]=function_objective_value(f,x_init,T,state_size_MILP,P_Sum,state_variable,power_variable,repair_x_state,repair_x_power,windows_start,windows_end)
state_variable(windows_start:windows_end,:)=repair_x_state';
power_variable(windows_start:windows_end,:)=repair_x_state'.*repair_x_power';

x_init(1:T*state_size_MILP)=reshape(state_variable,T*state_size_MILP,1);
x_init(T*state_size_MILP+1:2*T*state_size_MILP)=reshape(power_variable,T*state_size_MILP,1);

x_init(length(f)-T+1:end)=abs(P_Sum-sum(power_variable,2));
x_init(2*T*state_size_MILP+1:2*T*state_size_MILP+(T-1)*state_size_MILP)=reshape(abs(state_variable(2:end,:)-state_variable(1:end-1,:)),(T-1)*state_size_MILP,1);
objective_value=f*x_init;
end

function [objective_value]=function_objective_value_by_solver(model,x_init,T,state_size_MILP,state_variable,repair_x_state,windows_start,windows_end)
state_variable(windows_start:windows_end,:)=repair_x_state';

x_init(1:T*state_size_MILP)=reshape(state_variable,T*state_size_MILP,1);

model.lb(1:T*state_size_MILP)=reshape(state_variable,T*state_size_MILP,1);
model.ub(1:T*state_size_MILP)=reshape(state_variable,T*state_size_MILP,1);
model.ctype(1:end)='C';
[result] = solve(model,0.001,3000);
objective_value=result.objval;
end
