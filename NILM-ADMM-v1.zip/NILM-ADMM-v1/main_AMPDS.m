%AMPDS:{ 'RSE',	'GRE',	'MHE',	'B1E'	,'BME'	,'CWE',	'DWE','EQE','FRE',	'HPE',	'OFE',	'UTE',	'WOE',	'B2E',	'CDE',	'DNE',	'EBE',	'FGE',	'HTE',	'OUE',	'TVE',	'UNE'}
%AMPDS_alwaysOn:[1,0,1,0,0,0,0,1,1,0,1,1,0,0,0,0,0,0,0,0,1,1]
%AMPDS_Appliance_State_num=[3,3,3,3,2,3,2,3,3,2,4,3,2,2,2,3,0,3,3,3,2,5];
clear all;
data_Folder_Path='data\';
data_Set={'AMPDS','UKDALE','REFIT'};
data_type={'active power','reactive power'};

select_data_Set={'AMPDS'};
select_data_type={'P'};% P is active power  Q is reactive power
select_appliance_name={'CDE','FRE','DWE','HPE' ,'BME','TVE','CWE'}; % 20��û�п���,,'CDE','FRE','DWE','HPE' ,'BME','TVE','CWE'

%{'CDE', 'FRE', 'DWE', 'HPE'};

AMPDS_S=[3,3,3,3,3,2,3,2,3,2,2,4,2,2,2,2,3,0,3,3,3,2,5];
AMPDS_alwaysOn=[1,1,0,1,0,0,0,0,1,1,0,1,1,0,0,0,0,0,0,0,0,1,1];
BQP_result=[];
OLDA_result=[];
EMILP_result=[];
NSAC=[];
train_day_num=20;
test_day_num=1;
train_data_num=60*24*train_day_num;
TIME=10000;
partition_num=1;
result_path=strcat('result/AMPDS/result_','applianceNum',num2str(length(select_appliance_name)),'_trainday',num2str((train_day_num/partition_num)),'_testday',num2str((test_day_num/partition_num)),'_runTime',num2str(TIME),'_snr','.txt');
partition_index=1;
LOG=[];
power_result=[];

% for snr=35:-5:10
for partition_index=1:7
    %         result_path=strcat('result/AMPDS/result_','applianceNum',num2str(length(select_appliance_name)),'_trainday',num2str((train_day_num/partition_num)),'_testday',num2str((test_day_num/partition_num)),'_runTime',num2str(TIME),'_snr',num2str(snr),'.txt');
    
    test_data_num=60*24*(test_day_num/partition_num);
    train_data_start_location = 1; % ѵ������������ʼ��
    test_data_start_location = (train_data_num+test_data_num*(partition_index-1)+1)*ones(length(select_appliance_name),1);%[31200; 4500; 5700; 14000];
    
    %preposs
    [Total_data,train_data,test_data,appliance_location] = function_read_data(data_Folder_Path,select_data_Set,select_data_type,select_appliance_name,...
        train_data_num,test_data_num,train_data_start_location,test_data_start_location);
    
    S=AMPDS_S(appliance_location);
    always_On_appliance=AMPDS_alwaysOn(appliance_location);
    
    index_appliance=[];
    for i=1:length(select_appliance_name)
        index_appliance=[index_appliance;i*ones(S(i),1)];
    end
    
    cluster_id=[];
    for i=1:length(select_appliance_name)
        eval(strcat('input_data=','[[1:size(train_data.',select_data_Set{1},'.appliance_',select_data_type{1},',1)]'',','train_data.',select_data_Set{1},'.appliance_',select_data_type{1},'(:,i)];'));
        [result_Idx]=function_getStateNumByKmean(input_data(:,2),select_appliance_name{i},-1,S(i)); %%if want to use elbow rule ,change '-1' to 'i'
        cluster_id=[cluster_id,result_Idx];
    end
    
    N = length(S); % �����豸����
    state_size = sum(S);
    T=test_data_num;
    %% MILP
    
    [P, P_top, P_bottom, State_Limit, P_test, P_Sum, Transition_model, Omega, P_train,penlty_s,penlty_l,State_max_Limit,class_num,Space_division_strategy,windows_index] = DataProcessing_MILP(train_data,test_data,select_appliance_name,select_data_type,select_data_Set,S,cluster_id,train_data_num,test_data_num,train_day_num,always_On_appliance,test_day_num);
    P_test=num2cell(test_data.AMPDS.appliance_P,1);
    disp('data processing Done!');
    C_start=3.4078;
    C_run=2.1731;%2.1731;
    % validate_day_num=6;
    % validate_data_num=60*24*validate_day_num;
    % validate_data_num=60*24*1;
    % validate_data_location=60*24*(train_day_num-validate_day_num)+1:60*24*(train_day_num-validate_day_num+1);%60*24*train_day_num;
    % [C_sart,C_run]=function_grid_search(P,P_top, P_bottom, State_Limit , train_data.AMPDS.appliance_P, Transition_model, Omega,validate_data_num,class_num,1,validate_data_location,select_appliance_name,penlty_s,penlty_l,state_size,validate_data_num,N,10,10,3,10,always_On_appliance);
    
    % [model_EMILP] = function_construction_EMILP(P_top, P_bottom, Q_top, Q_bottom, State_Limit , P_Sum, Q_Sum, P_up, P_down, Q_up, Q_down, Transition_model, Omega,test_data_num,S,test_day_num,penlty_s,penlty_l,C_start,C_run);
    state_size_MILP = sum(class_num);
    Input_parameter.P_top=P_top; %�����Ͻ�
    Input_parameter.P_bottom=P_bottom; %�����½�
    Input_parameter.P_mid=P; %����
    Input_parameter.State_Limit=State_Limit; %��С�ʱ��
    Input_parameter.Transition_model=Transition_model; %״̬ת������
    Input_parameter.Omega=Omega;
    Input_parameter.S=class_num;
    Input_parameter.test_day_num=test_day_num;
    Input_parameter.alway_on_matri=always_On_appliance;
    Input_parameter.penlty_l=penlty_l;
    Input_parameter.C_start=C_start;
    Input_parameter.C_run=C_run;
    Input_parameter.P_Sum=P_Sum;
    Input_parameter.P_total=P_Sum;
    Input_parameter.test_data_num=test_data_num;
    Input_parameter.penlty_s=penlty_s;
    Input_parameter.class_num=class_num;
    Input_parameter.T=T;
    Input_parameter.state_variable_location=1:state_size_MILP*T;
    Input_parameter.power_variable_location=state_size_MILP*T+1:2*state_size_MILP*T;
    Input_parameter.horizion_divide=0;
    Input_parameter.windows_index=windows_index;
    
    [model_EMILP.total] = function_construct_MILP(Input_parameter);
 
    disp('Model construct!');
    %% ADMM
    [result] = function_p_norm_box_ADMM(model_EMILP.total);
    runtime=result.runtime+model_EMILP.total.init_time;
    disp('ADMM_RD Optimize done!!');
    x_value=result.x;
    log=result.log;


%% ADMM+RD
%     [result] = function_p_norm_box_ADMM_RD(model_EMILP.total);
%     runtime=result.runtime+model_EMILP.total.init_time;
%     disp('ADMM_RD Optimize done!!');
%     log=result.log;
% 
%     x_value=result.x;
%     disp('NS Optimize done!!');



    %% ADMM+RD+NS
    [result] = function_p_norm_box_ADMM_RD(model_EMILP.total);
    runtime=result.runtime+model_EMILP.total.init_time;
    disp('ADMM_RD Optimize done!!');
    log=result.log;
    %NS
    Input_parameter.f=model_EMILP.total.f;
    Input_parameter.penlty_s=penlty_s;
    Input_parameter.model=model_EMILP.total.model_NS;
    [result_refine] = function_NS(result.x,Input_parameter);
    runtime=runtime+result_refine.time;
    x_value=result_refine.x;
    disp('NS Optimize done!!');
    
    %% GUROBI
    % [result] = solve(model_EMILP.total,0.005,610);
    % x_value=result.x;
    % runtime=result.runtime;
    % disp('GUROBI Optimize done!!');
    
    
    %% ADMM+RD+NS+horizon divide
% Input_parameter.kesi_variable_location=length(model_EMILP.total.f)-T+1:length(model_EMILP.total.f);
% Input_parameter.horizion_divide=1;
% Input_parameter.T_origin=T;
% for i=1:size(windows_index,1)
%     Input_parameter.P_Sum=P_Sum(windows_index(i,1):windows_index(i,2));  %�ܹ���
%     Input_parameter.test_data_num=windows_index(i,2)-windows_index(i,1)+1;
%     Input_parameter.penlty_s=penlty_s;
%     Input_parameter.horizon_windows_index=windows_index(i,1):windows_index(i,2);
%     [model_EMILP.partition{i}] = function_construct_MILP(Input_parameter);
% %     [result] = solve(model_EMILP.partition{i},0.005,610);
% %     EMILP_x=round(reshape(result.x(1:state_size_MILP*Input_parameter.test_data_num),Input_parameter.test_data_num,state_size_MILP));
% end
%     model_EMILP.windows_index=windows_index;
% 
%     [result] = function_p_norm_box_ADMM_horizon_RD(model_EMILP);
%     runtime=result.runtime+model_EMILP.total.init_time;
%     disp('ADMM+RD+NS+horizon divide Optimize done!!');
%     log=result.log;
%     %
%     Input_parameter.pelty_s=penlty_s;
%     Input_parameter.f=model_EMILP.total.f;
%     Input_parameter.model=model_EMILP.total.model_NS;
%     [result_refine] = function_NS(result.x,Input_parameter);
%     runtime=runtime+result_refine.time;
%     x_value=result_refine.x;
%     disp('NS Optimize done!!');

    %% ADMM+RD+NS+horizon divide parall
%     Input_parameter.kesi_variable_location=length(model_EMILP.total.f)-T+1:length(model_EMILP.total.f);
% Input_parameter.horizion_divide=1;
% Input_parameter.T_origin=T;
% for i=1:size(windows_index,1)
%     Input_parameter.P_Sum=P_Sum(windows_index(i,1):windows_index(i,2));  %�ܹ���
%     Input_parameter.test_data_num=windows_index(i,2)-windows_index(i,1)+1;
%     Input_parameter.penlty_s=penlty_s;
%     Input_parameter.horizon_windows_index=windows_index(i,1):windows_index(i,2);
%     [model_EMILP.partition{i}] = function_construct_MILP(Input_parameter);
% %     [result] = solve(model_EMILP.partition{i},0.005,610);
% %     EMILP_x=round(reshape(result.x(1:state_size_MILP*Input_parameter.test_data_num),Input_parameter.test_data_num,state_size_MILP));
% end
%     model_EMILP.windows_index=windows_index;
% 
%     [result] = function_p_norm_box_ADMM_horizon_RD_parall(model_EMILP);
%     runtime=result.runtime+model_EMILP.total.init_time;
%     disp('ADMM+RD+NS+horizon divide Optimize done!!');
%     log=result.log;
%     %
%     Input_parameter.penlty_s=penlty_s;
%     Input_parameter.f=model_EMILP.total.f;
%     Input_parameter.model=model_EMILP.total.model_NS;
%     [result_refine] = function_NS(result.x,Input_parameter);
%     runtime=runtime+result_refine.time;
%     x_value=result_refine.x;
%     disp('NS Optimize done!!');
    
    
    
    
    
    %% result
    
index_appliance_MILP=[];
for i=1:length(select_appliance_name)
    index_appliance_MILP=[index_appliance_MILP;i*ones(class_num(i),1)];
end
    EMILP_x=round(reshape(x_value(1:state_size_MILP*T),T,state_size_MILP));%round(reshape(result_x,T,state_size_MILP));%;%result_x;
    
    P_value =reshape(x_value(state_size_MILP*T+1:state_size_MILP*T*2, :),T,state_size_MILP);%result_p;% reshape(result_p,T,state_size_MILP);% % ȡ����������Pit��ֵ
    % P_value = repmat(P',T,1);
    %device_state = x_value(1:state_size_MILP*T, :); % ȡ��0-1����Xit��ֵ
    power_appliance=EMILP_x.*P_value;%
    Decompose_data = {};
    predict_sum = sparse(test_data_num, 1);
    for  i= 1:N
        index_i=find(index_appliance_MILP==i);
        decompose =sum(power_appliance(:,index_i),2);
        Decompose_data{i} = decompose;
        predict_sum = predict_sum+Decompose_data{i};
    end
    
    
    %envelope
    % error=abs(P_Sum-predict_sum);
    % input.P=P_Sum;
    % input.rou=5;
    % input.x0=power_appliance;
    % input.p_max=P_top;
    % input.p_min=P_bottom;
    % input.T=T;
    % input.error=error;
    % input.P_value=repmat(P',T,1);
    % input.P_power=P;
    % input.state_size=sum(class_num);
    % [result_envelope] = function_envelope_method(input);
    
    disp('Decompose done!!');
    % power_appliance=result_envelope.x';
    % Decompose_data = {};
    % predict_sum = sparse(test_data_num, 1);
    % for  i= 1:N
    %     index_i=find(index_appliance_MILP==i);
    %     decompose =sum(power_appliance(:,index_i),2);
    %     Decompose_data = [Decompose_data; decompose];
    %      predict_sum = predict_sum+Decompose_data{i};
    % end
    x_axis = 1:1:T; % T�����x����
    
    figure(1)          % define figure
    Decompose_result=[];
    for i = 1:N
        subplot(N+2,1,i);     % subplot(x,y,n)x��ʾ��ʾ��������y��ʾ������n��ʾ�ڼ���ͼƬ
        plot(x_axis, Decompose_data{i}, x_axis, P_test{i});
        legend('predict','true');
        title(select_appliance_name{i});
        Decompose_result=[Decompose_result,Decompose_data{i}];
    end
    subplot(N+2,1,N+1);     % subplot(x,y,n)x��ʾ��ʾ��������y��ʾ������n��ʾ�ڼ���ͼƬ
    error=abs(P_Sum-predict_sum);
    plot(x_axis, sparse(T,1), x_axis, error);
    legend('predict','unknow');
    title('unknow device');
    
    subplot(N+2,1,N+2);     % subplot(x,y,n)x��ʾ��ʾ��������y��ʾ������n��ʾ�ڼ���ͼƬ
    plot(x_axis, predict_sum, x_axis, P_Sum);
    legend('predict','true');
    title('Total consumption');
    
    
    
    EMILP_Power=Decompose_data;
    [RSE_EMILP, R_square_EMILP, AC_EMILP, h_predict_EMILP, h_true_EMILP, h_error_EMILP,OCC_EMILP,FS_EMILP] = evaluation_func(P_test, Decompose_data,EMILP_x,S,always_On_appliance);
    model_EMILP=[];
    
    
    
    
    
    %%
    % RSE=[RSE_CO,RSE_SO,RSE_ALIP,RSE_OLDA,RSE_BQP,RSE_EMILP];
    % R_square=[R_square_CO,R_square_SO,R_square_ALIP,R_square_OLDA,R_square_BQP,R_square_EMILP];
    % AC=[AC_CO,AC_SO,AC_ALIP,AC_OLDA,AC_BQP,AC_EMILP];
    % h_error=[h_error_CO,h_error_SO,h_error_ALIP,h_error_OLDA,h_error_BQP,h_error_EMILP];
    % OCC=[OCC_CO,OCC_SO,OCC_ALIP,OCC_OLDA,OCC_BQP,OCC_EMILP];
    % FS=[FS_CO,FS_SO,FS_ALIP,FS_OLDA,FS_BQP,FS_EMILP];
    % time=[result_CO.runtime,result_SO.runtime,result_ALIP.runtime,result_OLDA.runtime,result_BQP.runtime,result.runtime];
    
    
    % RSE=[RSE_CO,RSE_SO,RSE_ALIP,RSE_EMILP];
    % R_square=[R_square_CO,R_square_SO,R_square_ALIP,R_square_EMILP];
    % AC=[AC_CO,AC_SO,AC_ALIP,AC_EMILP];
    % h_error=[h_error_CO,h_error_SO,h_error_ALIP,h_error_EMILP];
    % OCC=[OCC_CO,OCC_SO,OCC_ALIP,OCC_EMILP];
    % FS=[FS_CO,FS_SO,FS_ALIP,FS_EMILP];
    % time=[result_CO.runtime,result_SO.runtime,result_ALIP.runtime,result.runtime];
    
    
    
    
    
    % RSE=[RSE_CO,RSE_SO,RSE_ALIP,RSE_EMILP];
    % R_square=[R_square_CO,R_square_SO,R_square_ALIP,R_square_EMILP];
    % AC=[AC_CO,AC_SO,AC_ALIP,AC_EMILP];
    % h_error=[h_error_CO,h_error_SO,h_error_ALIP,h_error_EMILP];
    % time=[result_CO.runtime,result_SO.runtime,result_ALIP.runtime,result.runtime];
    
    
    % OLDA_result=[];
    EMILP_result=[EMILP_result;RSE_EMILP,R_square_EMILP,AC_EMILP,h_error_EMILP,[OCC_EMILP;sparse(size(RSE_EMILP,1)-1,size(OCC_EMILP,2))],FS_EMILP,[runtime;sparse(size(RSE_EMILP,1)-1,1)]];
    LOG=[LOG;log;sparse(1,size(log,2))];
        power_result=[power_result;Decompose_result];
    % OLDA_result=[OLDA_result;RSE_OLDA,R_square_OLDA,AC_OLDA,h_error_OLDA,[OCC_OLDA;sparse(size(RSE_OLDA,1)-1,size(OCC_OLDA,2))],FS_OLDA,[result_OLDA.runtime;sparse(size(RSE_OLDA,1)-1,1)]];
    %
    %
    % BQP_result=[BQP_result;RSE_BQP,R_square_BQP,AC_BQP,h_error_BQP,[OCC_BQP;sparse(size(RSE_BQP,1)-1,size(OCC_BQP,2))],FS_BQP,[result_BQP.runtime;sparse(size(RSE_BQP,1)-1,1)]];
    
    
    % result_data=[RSE,R_square,AC,h_error,[OCC;sparse(size(RSE,1)-1,size(OCC,2))],FS,[time;sparse(size(RSE,1)-1,size(time,2))]];
    % % % %
    % writematrix(result_data,result_path,'Delimiter','tab','WriteMode','append');
    % writecell(EMILP_Power,strcat('result/AMPDS/Power_EMILP_','applianceNum',num2str(length(select_appliance_name)),'_trainday',num2str((train_day_num/partition_num)),'_testday',num2str((test_day_num/partition_num)),'_runTime',num2str(TIME),'_SNR',num2str(snr),'_iter',num2str(partition_index),'.txt'),'Delimiter','tab','WriteMode','append');
    % writecell(CO_Power,strcat('result/AMPDS/Power_CO_','applianceNum',num2str(length(select_appliance_name)),'_trainday',num2str((train_day_num/partition_num)),'_testday',num2str((test_day_num/partition_num)),'_runTime',num2str(TIME),'_SNR',num2str(snr),'_iter',num2str(partition_index),'.txt'),'Delimiter','tab','WriteMode','append');
    % writecell(SO_Power,strcat('result/AMPDS/Power_SO_','applianceNum',num2str(length(select_appliance_name)),'_trainday',num2str((train_day_num/partition_num)),'_testday',num2str((test_day_num/partition_num)),'_runTime',num2str(TIME),'_SNR',num2str(snr),'_iter',num2str(partition_index),'.txt'),'Delimiter','tab','WriteMode','append');
    % writecell(OLDA_Power,strcat('result/AMPDS/Power_OLDA_','applianceNum',num2str(length(select_appliance_name)),'_trainday',num2str((train_day_num/partition_num)),'_testday',num2str((test_day_num/partition_num)),'_runTime',num2str(TIME),'_SNR',num2str(snr),'_iter',num2str(partition_index),'.txt'),'Delimiter','tab','WriteMode','append');
    % writecell(ALIP_Power,strcat('result/AMPDS/Power_ALIP_','applianceNum',num2str(length(select_appliance_name)),'_trainday',num2str((train_day_num/partition_num)),'_testday',num2str((test_day_num/partition_num)),'_runTime',num2str(TIME),'_SNR',num2str(snr),'_iter',num2str(partition_index),'.txt'),'Delimiter','tab','WriteMode','append');
    % writecell(BQP_Power,strcat('result/AMPDS/Power_BQP_','applianceNum',num2str(length(select_appliance_name)),'_trainday',num2str((train_day_num/partition_num)),'_testday',num2str((test_day_num/partition_num)),'_runTime',num2str(TIME),'_SNR',num2str(snr),'_iter',num2str(partition_index),'.txt'),'Delimiter','tab','WriteMode','append');
    
    % [NSAC_EMILP] = function_NSAC(strcat('result/AMPDS/Power_EMILP_','applianceNum',num2str(length(select_appliance_name)),'_trainday',num2str((train_day_num/partition_num)),'_testday',num2str((test_day_num/partition_num)),'_runTime',num2str(TIME),'_iter',num2str(partition_index),'.txt'),P_test,S,always_On_appliance,N);
    % [NSAC_CO] = function_NSAC(strcat('result/AMPDS/Power_CO_','applianceNum',num2str(length(select_appliance_name)),'_trainday',num2str((train_day_num/partition_num)),'_testday',num2str((test_day_num/partition_num)),'_runTime',num2str(TIME),'_iter',num2str(partition_index),'.txt'),P_test,S,always_On_appliance,N);
    % [NSAC_SO] = function_NSAC(strcat('result/AMPDS/Power_SO_','applianceNum',num2str(length(select_appliance_name)),'_trainday',num2str((train_day_num/partition_num)),'_testday',num2str((test_day_num/partition_num)),'_runTime',num2str(TIME),'_iter',num2str(partition_index),'.txt'),P_test,S,always_On_appliance,N);
    % [NSAC_OLDA] = function_NSAC(strcat('result/AMPDS/Power_OLDA_','applianceNum',num2str(length(select_appliance_name)),'_trainday',num2str((train_day_num/partition_num)),'_testday',num2str((test_day_num/partition_num)),'_runTime',num2str(TIME),'_iter',num2str(partition_index),'.txt'),P_test,S,always_On_appliance,N);
    % [NSAC_ALIP] = function_NSAC(strcat('result/AMPDS/Power_ALIP_','applianceNum',num2str(length(select_appliance_name)),'_trainday',num2str((train_day_num/partition_num)),'_testday',num2str((test_day_num/partition_num)),'_runTime',num2str(TIME),'_iter',num2str(partition_index),'.txt'),P_test,S,always_On_appliance,N);
    % [NSAC_BQP] = function_NSAC(strcat('result/AMPDS/Power_BQP_','applianceNum',num2str(length(select_appliance_name)),'_trainday',num2str((train_day_num/partition_num)),'_testday',num2str((test_day_num/partition_num)),'_runTime',num2str(TIME),'_iter',num2str(partition_index),'.txt'),P_test,S,always_On_appliance,N);
    %
    % NSAC=[NSAC;NSAC_CO,NSAC_SO,NSAC_ALIP,NSAC_OLDA,NSAC_BQP,NSAC_EMILP];
end
%     EMILP_result=[EMILP_result;sparse(1,size(EMILP_result,2))];
% end
