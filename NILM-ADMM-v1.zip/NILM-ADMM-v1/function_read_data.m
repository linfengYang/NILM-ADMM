function [Total_data,train_data,test_data,location,S,always_On_appliance] = function_read_data(data_Folder_Path,select_data_Set,select_data_type,select_appliance_name,train_data_num,test_data_num,train_data_start_location,test_data_start_location)
%FUNCTION_READ_DATA �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

for i=1:length(select_data_Set)
    switch select_data_Set{i}
        case 'AMPDS'
            
            all_electricity={'WHE', 'RSE',	'GRE',	'MHE',	'B1E'	,'BME'	,'CWE',	'DWE'...
                'EQE',	'FRE',	'HPE',	'OFE',	'UTE',	'WOE',	'B2E',	'CDE',	'DNE',	'EBE',	'FGE',	'HTE',	'OUE',	'TVE',	'UNE'
                };
            AMPDS_S=[3,3,3,3,3,2,3,2,3,2,2,4,3,2,2,2,3,0,3,3,3,2,5];
            AMPDS_alwaysOn=[1,1,0,1,0,0,0,0,1,1,0,1,1,0,0,0,0,0,0,0,0,1,1];
            
            for j=1:length(select_data_type)
                switch select_data_type{j}
                    case 'P'
                        file_path{j,1}=strcat(data_Folder_Path,select_data_Set{i},'\','Electricity_P.csv');
                         file_path{j,2}='P';
                    case 'Q'
                        file_path{j,1}=strcat(data_Folder_Path,select_data_Set{i},'\','Electricity_Q.csv');
                        file_path{j,2}='Q';
                    otherwise
                        warning('no exist this data type!');
                        break;
                end
            end
            
            for j=1:size(file_path,1)
                eval(strcat('Total_data','.','AMPDS','.',file_path{j,2},'=readmatrix(file_path{j,1});'));
            end
            
            for j=1:length(select_appliance_name)
                [row(j),location(j)]=find(strcmp(all_electricity,select_appliance_name{j})==1);
            end
            
            if(isfield(Total_data.AMPDS,'P'))
               train_data.AMPDS.appliance_P=Total_data.AMPDS.P(train_data_start_location:train_data_start_location+train_data_num-1,location+1);
               train_data.AMPDS.timeIndex=Total_data.AMPDS.P(train_data_start_location:train_data_start_location+train_data_num-1,1);
               test_data.AMPDS.appliance_P=[];
               test_data.AMPDS.timeIndex=[];
               for j=1:length(test_data_start_location)
                test_data.AMPDS.appliance_P=[test_data.AMPDS.appliance_P,Total_data.AMPDS.P(test_data_start_location(j):test_data_num+test_data_start_location(j)-1,location(j)+1)];
                test_data.AMPDS.timeIndex=[test_data.AMPDS.timeIndex,Total_data.AMPDS.P(test_data_start_location(j):test_data_num+test_data_start_location(j)-1,1)];
               end
            else
                train_data.AMPDS.appliance_P=[];
                test_data.AMPDS.appliance_P=[];
            end
            
            if(isfield(Total_data.AMPDS,'Q'))
               train_data.AMPDS.appliance_Q=Total_data.AMPDS.Q(train_data_start_location:train_data_start_location+train_data_num-1,location+1);
              test_data.AMPDS.appliance_Q=[];
               for j=1:length(test_data_start_location)
                   test_data.AMPDS.appliance_Q=[test_data.AMPDS.appliance_Q,Total_data.AMPDS.Q(test_data_start_location(i):test_data_num+test_data_start_location(i)-1,location(i)+1)];
               end
            else
               train_data.AMPDS.appliance_Q=[]; 
               test_data.AMPDS.appliance_Q=[];
            end
            
            S=AMPDS_S(location);
            always_On_appliance=AMPDS_alwaysOn(location);
            
            
        case 'UKDALE'
            
        case 'REFIT'
             REFIT_S=[2,2,2,3,2,3,2,2,2];
             REFIT_alwaysOn=[0,0,0,0,0,0,0,0,0];
            all_electricity(3)={'Television','Fridge-Freezer','Freezer','Microwave','Kettle','Toaster','Washing Machine','Tumble Dryer','Dishwasher'};
            all_electricity(5)={'Television','Fridge-Freezer','Microwave','Kettle','Toaster','Washing Machine','Tumble Dryer','Dishwasher','Computer'};

            for j=1:length(select_data_type)
                file_path{j}=strcat(data_Folder_Path,select_data_Set{i},'\',select_data_type{j},'.csv');
            end
            for j=1:size(file_path,2)
                eval(strcat('Total_data','.','REFIT','.',select_data_type{j},'=readmatrix(file_path{j});'));
            end
            
            for j=1:length(select_appliance_name)
                [row(j),location(j)]=find(strcmp(all_electricity(3),select_appliance_name{j})==1);
            end
            
            for j=1:length(select_data_type)
                 eval(strcat('train_data.REFIT.','appliance_P','=Total_data.REFIT.',select_data_type{j},'(train_data_start_location:train_data_start_location+train_data_num-1,location+3);'));
                eval(strcat('train_data.REFIT.timeIndex=','Total_data.REFIT.',select_data_type{j},'(train_data_start_location:train_data_start_location+train_data_num-1,2);'));
                eval(strcat('test_data.REFIT.','appliance_P','=[];'));
                eval(strcat('test_data.REFIT.timeIndex=[];'));
                for k=1:length(test_data_start_location)
                    eval(strcat('test_data.REFIT.','appliance_P','=[test_data.REFIT.','appliance_P',',Total_data.REFIT.',select_data_type{j},'(test_data_start_location(k):test_data_num+test_data_start_location(k)-1,location(k)+3)','];'));
                    eval(strcat('test_data.REFIT.timeIndex=[test_data.REFIT.timeIndex,Total_data.REFIT.',select_data_type{j},'(test_data_start_location(k):test_data_num+test_data_start_location(k)-1,1)];'));
                end
            end
            S=REFIT_S(location);
            always_On_appliance=REFIT_alwaysOn(location);
            
        otherwise
            warning('Unexpected data Set. Please check data Set');
    end
    
    
    
    
    
end


end

