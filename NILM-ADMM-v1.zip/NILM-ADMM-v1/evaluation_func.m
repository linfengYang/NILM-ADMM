function [RSE, R_square, AC, h_predict, h_true, h_error,OCC,FS] = evaluation_func(true_list, predict_list,predict_x,S,always_On_appliance)
    N = length(true_list);
    RSE = calculate_RSE(true_list, predict_list, N);
    R_square = calculate_R_square(true_list, predict_list, N);
    AC = calculate_AC(true_list, predict_list, N);
    h_predict = calculate_h_predict(predict_list, N);
    h_true = calculate_h_true(true_list, N);
    h_error =  calculate_h_error(h_true, h_predict, N);
    OCC= calculate_OCC(true_list, predict_list);
   FS= calculate_FS(predict_x,predict_list, true_list,S,N,always_On_appliance);
end

function [ans] = calculate_RSE(true_list, predict_list, N)
    ans = [];
    for i = 1:N
        true_data = true_list{i};
        predict = predict_list{i};
        if(sum(true_data.^2)~=0)
        ans = [ans; sum((true_data-predict).^2) / sum(true_data.^2)];
        else
            if(sum(predict.^2)~=0)
            ans = [ans; sum((true_data-predict).^2) / sum(predict.^2)];
            else
                ans = [ans;0];
            end
        end
    end
end

function [ans] = calculate_R_square(true_list, predict_list, N)
    ans = [];
    for i = 1:N
         true_data = true_list{i};
        avg = mean(true_data);
        predict = predict_list{i};
        if(sum(true_data.^2)~=0)
            ans = [ans; 1-(sum((true_data-predict).^2) / sum((true_data-avg).^2))];
        else
            if(sum(predict.^2)~=0)
                avg = mean(predict);
                ans = [ans; 1-(sum((predict-true_data).^2) / sum((predict-avg).^2))];
            else
                ans = [ans;1];
            end
        end
    end
end

function [ans] = calculate_AC(true_list, predict_list, N)
    ans = [];
    for i = 1:N
        true_data = true_list{i};
        predict = predict_list{i};
        if(sum(true_data)~=0)
            ans = [ans; 1-sum(abs(true_data-predict))/(2*sum(true_data))];
        else
            if(sum(predict)~=0)
               ans = [ans; 1-sum(abs(true_data-predict))/(2*sum(predict))];
            else
                ans = [ans;1];
            end
        end
    end
end

function [ans] = calculate_h_predict(predict_list, N)
    ans = [];
    bottom = 0;
    for i = 1:N
        bottom = bottom + sum(predict_list{i});
    end
    if(bottom~=0)
        for i = 1:N
            predict = predict_list{i};
            ans = [ans; sum(predict) / bottom];
        end
    else
        for i = 1:N
           ans = [ans; 0];
        end
    end
end

function [ans] = calculate_h_true(true_list, N)
    ans = [];
    bottom = 0;
    for i = 1:N
        bottom = bottom + sum(true_list{i});
    end
    if(bottom~=0)
        for i = 1:N
            true_data = true_list{i};
            ans = [ans; sum(true_data) / bottom];
        end
    else
        for i = 1:N
            ans = [ans; 0];
        end
    end
end

function [ans] = calculate_h_error(h_true, h_predict, N)
    ans = [];
    for i =1:N
        if(h_true(i,:)~=0)
        ans = [ans; abs(h_true(i,:) - h_predict(i,:) )/h_true(i,:)];
        else
            if(h_predict(i,:)~=0)
                ans = [ans; abs(h_true(i,:) - h_predict(i,:) )/h_predict(i,:)];
            else
                ans = [ans; 0];
            end
        end
    end
end

function  [ans] = calculate_OCC(true_list, predict_list)
true_list=cell2mat(true_list);
if(sum(true_list,'all')~=0)
    predict_list=cell2mat(predict_list);
    diff=sum(abs(true_list-predict_list),'all');
    ans=1-diff/(2*sum(true_list,'all'));
else
    predict_list=cell2mat(predict_list');
    if(sum(predict_list,'all')==0)
        ans=1;
    else
         diff=sum(abs(true_list-predict_list),'all');
        ans=1-diff/(2*sum(predict_list,'all'));
    end
end
end

function  [ans] =calculate_FS(predict_x,predict_list,true_list,S, N,always_On_appliance)
predict_x=predict_x';
true_x=[];
x_value=[];
if(size(predict_x,2)==sum(S))
    for i=1:N
        [result_Idx,C,sumD,D] = kmeans(true_list{i},S(i),'dist','sqEuclidean','Replicates',4);
        cluster_Idx=result_Idx;
        C_sort=sort(C);
        for j=1:S(i)
            
            if(sum(C_sort)~=0)
                index_row=find(C==C_sort(j));
                index_cluter=find(result_Idx==index_row);
                cluster_Idx(index_cluter)=j;
            else
                cluster_Idx(1:end)=1;
            end
            
            if(i==1)
                predict_x(find(predict_x(:,j)==1),j)=j;
            else
                predict_x(find(predict_x(:,sum(S(1:i-1))+j)==1),sum(S(1:i-1))+j)=j;
            end
        end
        if(i==1)
            x_value=[x_value,sum(predict_x(:,1:S(i)),2)];
        else
            x_value=[x_value,sum(predict_x(:,sum(S(1:i-1))+1:sum(S(1:i-1))+S(i)),2)];
        end
        
        result_Idx=cluster_Idx;
        true_x=[true_x,result_Idx];
        
    end
    ans=[];
    for i=1:N
        if(sum(true_list{i}(find(true_x(:,i)>1)))>0)
        ans=[ans;sum(abs(true_list{i}(find(true_x(:,i)>1))-predict_list{i}(find(true_x(:,i)>1))))/sum(true_list{i}(find(true_x(:,i)>1)))];
        else
            ans=[ans;0];
        end
    end
else
    S_temp=S-1+always_On_appliance;
    for i=1:N
        [result_Idx,C,sumD,D] = kmeans(true_list{i},S(i),'dist','sqEuclidean','Replicates',4);
        cluster_Idx=result_Idx;
        C_sort=sort(C);
        for j=1:S(i)
            
            if(sum(C_sort)~=0)
                index_row=find(C==C_sort(j));
                index_cluter=find(result_Idx==index_row);
                if(always_On_appliance(i)==1)
                    cluster_Idx(index_cluter)=j;
                else
                    cluster_Idx(index_cluter)=j-1;
                end
            else
                cluster_Idx(1:end)=0;
            end
            

        end
        
        for j=1:S_temp(i)
            if(i==1)
                predict_x(find(predict_x(:,j)==1),j)=j;
            else
                predict_x(find(predict_x(:,sum(S_temp(1:i-1))+j)==1),sum(S_temp(1:i-1))+j)=j;
            end
        end
        
        if(i==1)
            x_value=[x_value,sum(predict_x(:,1:S_temp(i)),2)];
        else
            x_value=[x_value,sum(predict_x(:,sum(S_temp(1:i-1))+1:sum(S_temp(1:i-1))+S_temp(i)),2)];
        end
        
        result_Idx=cluster_Idx;
        true_x=[true_x,result_Idx];
        
    end
     ans=[];
    for i=1:N
        if(sum(true_list{i}(find(true_x(:,i)>0)))>0)
            ans=[ans;sum(abs(true_list{i}(find(true_x(:,i)>0))-predict_list{i}(find(true_x(:,i)>0))))/sum(true_list{i}(find(true_x(:,i)>0)))];
        else
            ans=[ans;0];
        end
    end
end
% ans=[];
% for i=1:N
%     ans=[ans;length(find(true_x(:,i)-x_value(:,i)~=0))/length(true_x(:,i))];
% end
end