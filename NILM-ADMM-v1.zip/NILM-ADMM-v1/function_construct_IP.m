function [model] = function_construct_IP(Input_parameter)
%FUNCTION_CONSTRUCT_MILP �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
% ����X_ijt+P_ijt+eta_ijt+kexPT+ = state_szie*T*3+T

P_top=Input_parameter.P_top; %�����Ͻ�
P_bottom=Input_parameter.P_bottom; %�����½�
P=Input_parameter.P_mid; %����
State_Limit=Input_parameter.State_Limit; %��С�ʱ��
P_Sum=Input_parameter.P_Sum;  %�ܹ���
Transition_model=Input_parameter.Transition_model; %״̬ת������
Omega=Input_parameter.Omega;
test_data_num=Input_parameter.test_data_num;
S=Input_parameter.S;
test_day_num=Input_parameter.test_day_num;
penlty_s=Input_parameter.penlty_s;
penlty_l=Input_parameter.penlty_l;
C_start=Input_parameter.C_start;
C_run=Input_parameter.C_run;
alway_on_matri=Input_parameter.alway_on_matri;

T=test_data_num;
% S=S+alway_on_matri-1;
N = length(S);% �����豸����
state_size = sum(S);

Total_variable_num=0;
%x location
state_variable_location(:,1)=1:T:state_size*T;
state_variable_location(:,2)=[state_variable_location(2:end,1)-1;state_size*T];
state_variable_length=state_size*T;
Total_variable_num=Total_variable_num+state_size*T;
%p
% power_variable_location(:,1)=state_variable_location(:,1)+state_size*T;
% power_variable_location(:,2)=state_variable_location(:,2)+state_size*T;
% power_variable_length=state_size*T;
% Total_variable_num=Total_variable_num+state_size*T;

%eta
eta_variable_location(:,1)=Total_variable_num+1:T-1:Total_variable_num+state_size*(T-1);
eta_variable_location(:,2)=[eta_variable_location(2:end,1)-1;Total_variable_num+state_size*(T-1)];
eta_variable_length=state_size*(T-1);
Total_variable_num=Total_variable_num+state_size*(T-1);

%kesi
kesi_variable_location(:,1)=Total_variable_num+1;
kesi_variable_location(:,2)=Total_variable_num+T;
kesi_variable_length=T;
Total_variable_num=Total_variable_num+kesi_variable_length;


index_appliance=[];
for i=1:N
    index_appliance=[index_appliance;i*ones(S(i),1)];
end

penalty_temp1 = C_start*Omega';
penalty_temp2 = reshape(repmat(penalty_temp1,T-1, 1),1,state_size*(T-1));

if(test_day_num>=1)
penlty_s=repmat(penlty_s,1,test_day_num);
penlty_l=repmat(penlty_l,1,T);
penlty_s=(1-penlty_s).*penlty_l;
penlty_s=reshape(C_run*penlty_s',1,state_size*T);
else
    penlty_s=penlty_s(:,1:size(penlty_s,2)*test_day_num);
penlty_l=repmat(penlty_l,1,T);
penlty_s=(1-penlty_s).*penlty_l;
penlty_s=reshape(C_run*penlty_s',1,state_size*T);
end
%quadr term

%the sum of squared differences
H=[];
% H_temp=[];
% for i=1:state_size
%     H_temp=[H_temp,sparse([1:T],[1:T],ones(1,T),T,T)];
% end
% for i=1:state_size
%     H=[H;sparse(T,state_variable_length),H_temp,sparse(T,eta_variable_length)];
% end
% 
% H=[sparse(state_variable_length,Total_variable_num);H;sparse(eta_variable_length,Total_variable_num)];



%һ����

% f = [penlty_s, -2*reshape(repmat(P_Sum,1,state_size),power_variable_length,1)', penalty_temp2];
f = [penlty_s, penalty_temp2,ones(1,kesi_variable_length)];
%��С�ʱ��Լ��
Aineq_min_active_time_constraint=[];
bineq_min_active_time_constraint=[];

for i=1:state_size
    state_vari_location=state_variable_location(i,1):state_variable_location(i,2);
    if(State_Limit(i)>1)
        if(State_Limit(i)>T)
            State_Limit(i)=T;
        end
        for j=1:State_Limit(i)-1
            x_t_1_location_row=1:T-j-1;
            x_t_1_location_col=state_vari_location(1:T-j-1);
            x_t_1_location_value=-1*ones(1,T-j-1);
            
            x_t_location_row=1:T-j-1;
            x_t_location_col=state_vari_location(2:T-j);
            x_t_location_value=ones(1,T-j-1);
            
            x_tao_location_row=1:T-j-1;
            x_tao_location_col=state_vari_location(j+2:T);
            x_tao_location_value=-1*ones(1,T-j-1);
            
            row_location=[x_t_1_location_row,x_t_location_row,x_tao_location_row];
            col_location=[x_t_1_location_col,x_t_location_col,x_tao_location_col];
            coefficient_value=[x_t_1_location_value,x_t_location_value,x_tao_location_value];
            
            constraint_min_active_time=sparse(row_location,col_location,coefficient_value,T-j-1,Total_variable_num);
            Aineq_min_active_time_constraint=[Aineq_min_active_time_constraint;constraint_min_active_time];
        end
    end
end
bineq_min_active_time_constraint=sparse(size(Aineq_min_active_time_constraint,1),1);


%���ʱ���Լ��
Aineq_power_bound_constraint=[];
bineq_power_bound_constraint=[];

%Max bound
% x_location_row=1:state_variable_length;
% x_location_col=1:state_variable_length;
% x_value=-1*reshape(repmat(P_top,1,T)',state_size*T,1);
% 
% p_location_row=1:state_variable_length;
% p_location_col=state_variable_length+1:state_variable_length+power_variable_length;
% p_value=ones(state_variable_length,1);
% 
% row_location=[x_location_row,p_location_row];
% col_location=[x_location_col,p_location_col];
% coefficient_value=[x_value;p_value];
% 
% Aineq_power_bound_constraint=[Aineq_power_bound_constraint;sparse(row_location,col_location,coefficient_value,state_variable_length,Total_variable_num)];
% bineq_power_bound_constraint=[bineq_power_bound_constraint;sparse(state_variable_length,1)];
% 
% %Min bound
% x_location_row=1:state_variable_length;
% x_location_col=1:state_variable_length;
% x_value=reshape(repmat(P_bottom,1,T)',state_size*T,1);
% 
% p_location_row=1:state_variable_length;
% p_location_col=state_variable_length+1:state_variable_length+power_variable_length;
% p_value=-1*ones(state_variable_length,1);
% 
% row_location=[x_location_row,p_location_row];
% col_location=[x_location_col,p_location_col];
% coefficient_value=[x_value,p_value];
% 
% Aineq_power_bound_constraint=[Aineq_power_bound_constraint;sparse(row_location,col_location,coefficient_value,state_variable_length,Total_variable_num)];
% bineq_power_bound_constraint=[bineq_power_bound_constraint;sparse(state_variable_length,1)];


%״̬ת��Լ��
Aineq_constraint_state_transition=[];
bineq_constraint_state_transition=[];

for i=1:N
    [row_index,col_index]=find(Transition_model{i}==0);
    if(~isempty(row_index))
        appliance_index=find(index_appliance==i);
        for j=1:length(row_index)
            state_location_col=[state_variable_location(appliance_index(row_index(j)),1):state_variable_location(appliance_index(row_index(j)),2)-1];
            constraint_state_transition=sparse([1:T-1],state_location_col,ones(1,T-1),T-1,Total_variable_num);
            
            state_location_col=[state_variable_location(appliance_index(col_index(j)),1)+1:state_variable_location(appliance_index(col_index(j)),2)];
            constraint_state_transition=constraint_state_transition+sparse([1:T-1],state_location_col,ones(1,T-1),T-1,Total_variable_num);
            Aineq_constraint_state_transition=[Aineq_constraint_state_transition;constraint_state_transition];
            bineq_constraint_state_transition=[bineq_constraint_state_transition;ones(T-1,1)];
        end
    end
end

%Multiple States Selected Constraints
Aineq_Multiple_States_Selected_Constraints=[];
bineq_Multiple_States_Selected_Constraints=[];

Aeq_Multiple_States_Selected_Constraints=[];
beq_Multiple_States_Selected_Constraints=[];

for i=1:N
    if(alway_on_matri(i)==1)
        appliance_index=find(index_appliance==i);
        state_location_row=[];
        state_location_col=[];
        for j=1:length(appliance_index)
            state_location_row=[state_location_row,1:T];
            state_location_col=[state_location_col,state_variable_location(appliance_index(j),1):state_variable_location(appliance_index(j),2)];
        end
        Aeq_Multiple_States_Selected_Constraints=[Aeq_Multiple_States_Selected_Constraints;...
            sparse(state_location_row,state_location_col,ones(1,size(state_location_col,2)),T,Total_variable_num)];
        beq_Multiple_States_Selected_Constraints=[beq_Multiple_States_Selected_Constraints;ones(T,1)];
    else
        appliance_index=find(index_appliance==i);
        state_location_row=[];
        state_location_col=[];
        for j=1:length(appliance_index)
            state_location_row=[state_location_row,1:T];
            state_location_col=[state_location_col,state_variable_location(appliance_index(j),1):state_variable_location(appliance_index(j),2)];
        end
        Aineq_Multiple_States_Selected_Constraints=[Aineq_Multiple_States_Selected_Constraints;...
            sparse(state_location_row,state_location_col,ones(1,size(state_location_col,2)),T,Total_variable_num)];
        bineq_Multiple_States_Selected_Constraints=[bineq_Multiple_States_Selected_Constraints;ones(T,1)];
    end
end


%Difference Constraints
Aineq_difference_constraints=[];
bineq_difference_constraints=[];

state_location_row=[];
state_location_col=[];
state_location_value=[];
for i=1:state_size
    state_location_row=[state_location_row,1:T];
    state_location_col=[state_location_col,state_variable_location(i,1):state_variable_location(i,2)];
    state_location_value=[state_location_value,-1*P(i)*ones(1,T)];
end

kesi_location_row=1:T;
kesi_location_col=kesi_variable_location(1):kesi_variable_location(2);
kesi_location_value=-1*ones(1,T);

var_location_row=[state_location_row,kesi_location_row];
var_location_col=[state_location_col,kesi_location_col];
var_location_value=[state_location_value,kesi_location_value];

Aineq_difference_constraints=[Aineq_difference_constraints;sparse(var_location_row,var_location_col,var_location_value,T,Total_variable_num)];
bineq_difference_constraints=[bineq_difference_constraints;-1*P_Sum];


state_location_row=[];
state_location_col=[];
state_location_value=[];
for i=1:state_size
    state_location_row=[state_location_row,1:T];
    state_location_col=[state_location_col,state_variable_location(i,1):state_variable_location(i,2)];
    state_location_value=[state_location_value,P(i)*ones(1,T)];
end

kesi_location_row=1:T;
kesi_location_col=kesi_variable_location(1):kesi_variable_location(2);
kesi_location_value=-1*ones(1,T);

var_location_row=[state_location_row,kesi_location_row];
var_location_col=[state_location_col,kesi_location_col];
var_location_value=[state_location_value,kesi_location_value];

Aineq_difference_constraints=[Aineq_difference_constraints;sparse(var_location_row,var_location_col,var_location_value,T,Total_variable_num)];
bineq_difference_constraints=[bineq_difference_constraints;P_Sum];


%plenty term
for i=1:state_size
    x_t_1_location_row=1:T-1;
    x_t_1_location_col=state_variable_location(i,1):state_variable_location(i,2)-1;
    x_t_1_location_value=-1*ones(1,T-1);
    
    x_t_location_row=1:T-1;
    x_t_location_col=state_variable_location(i,1)+1:state_variable_location(i,2);
    x_t_location_value=ones(1,T-1);
    
    eta_location_row=1:T-1;
    eta_location_col=eta_variable_location(i,1):eta_variable_location(i,2);
    eta_location_value=-1*ones(1,T-1);
    
    var_location_row=[x_t_1_location_row,x_t_location_row,eta_location_row];
    var_location_col=[x_t_1_location_col,x_t_location_col,eta_location_col];
    var_location_value=[x_t_1_location_value,x_t_location_value,eta_location_value];
    
    Aineq_difference_constraints=[Aineq_difference_constraints;sparse(var_location_row,var_location_col,var_location_value,T-1,Total_variable_num)];
    bineq_difference_constraints=[bineq_difference_constraints;sparse(T-1,1)];
    
    %%%%
    x_t_1_location_row=1:T-1;
    x_t_1_location_col=state_variable_location(i,1):state_variable_location(i,2)-1;
    x_t_1_location_value=ones(1,T-1);
    
    x_t_location_row=1:T-1;
    x_t_location_col=state_variable_location(i,1)+1:state_variable_location(i,2);
    x_t_location_value=-1*ones(1,T-1);
    
    eta_location_row=1:T-1;
    eta_location_col=eta_variable_location(i,1):eta_variable_location(i,2);
    eta_location_value=-1*ones(1,T-1);
    
    var_location_row=[x_t_1_location_row,x_t_location_row,eta_location_row];
    var_location_col=[x_t_1_location_col,x_t_location_col,eta_location_col];
    var_location_value=[x_t_1_location_value,x_t_location_value,eta_location_value];
    
    Aineq_difference_constraints=[Aineq_difference_constraints;sparse(var_location_row,var_location_col,var_location_value,T-1,Total_variable_num)];
    bineq_difference_constraints=[bineq_difference_constraints;sparse(T-1,1)];
    
end


Aineq=[Aineq_constraint_state_transition;Aineq_difference_constraints;Aineq_min_active_time_constraint;Aineq_Multiple_States_Selected_Constraints;Aineq_power_bound_constraint];
bineq=[bineq_constraint_state_transition;bineq_difference_constraints;bineq_min_active_time_constraint;bineq_Multiple_States_Selected_Constraints;bineq_power_bound_constraint];

Aeq=[Aeq_Multiple_States_Selected_Constraints];
beq=[beq_Multiple_States_Selected_Constraints];

ctype = '';
ctype(1:state_size*T) = 'C';
ctype(state_size*T+1:Total_variable_num) = 'C';
lb = sparse(Total_variable_num, 1);
ub = [ones(state_size*T, 1);inf*ones(Total_variable_num-state_variable_length,1)];

model.Q=H;
model.f = f;
model.Aineq = Aineq;
model.bineq = bineq;
model.Aeq = Aeq;
model.beq = beq;
model.lb=lb;
model.ub=ub;
model.ctype=ctype;
model.binary_var_location=1:state_size*T;

x=sparse(state_variable_length,1);
eta=sparse(eta_variable_length,1);
kesi=sparse(kesi_variable_length,1);

for i=1:state_size
    if(alway_on_matri(index_appliance(i))==1)
        [index_state_appliance]=find(index_appliance==index_appliance(i));
        [index_state]=find(i==index_state_appliance);
        if(index_state==1)
            x(state_variable_location(index_appliance(i),1):state_variable_location(index_appliance(i),2))=1;
        end
    end
end
solution=[x;eta;kesi];


init_x=[x;eta;kesi];
model.init_x=init_x;

end