function [model] = function_construct_MILP(Input_parameter)
%FUNCTION_CONSTRUCT_MILP �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
% ����X_ijt+P_ijt+eta_ijt+kexPT+ = state_szie*T*3+T

P_top=Input_parameter.P_top; %�����Ͻ�
P_bottom=Input_parameter.P_bottom; %�����½�
P=Input_parameter.P_mid; %����
State_Limit=Input_parameter.State_Limit; %��С�ʱ��
P_Sum=Input_parameter.P_Sum;  %�ܹ���
Transition_model=Input_parameter.Transition_model; %״̬ת������
Omega=Input_parameter.Omega;
test_data_num=Input_parameter.test_data_num;
S=Input_parameter.S;
test_day_num=Input_parameter.test_day_num;
penlty_s=Input_parameter.penlty_s;
penlty_l=Input_parameter.penlty_l;
C_start=Input_parameter.C_start;
C_run=Input_parameter.C_run;
alway_on_matri=Input_parameter.alway_on_matri;
windows_index=Input_parameter.windows_index;
horizion_divide=Input_parameter.horizion_divide;
T=test_data_num;

if(horizion_divide==1)
    T_origin=Input_parameter.T_origin;
    horizon_windows_index=Input_parameter.horizon_windows_index;
end
% S=S+alway_on_matri-1;
N = length(S);% �����豸����
state_size = sum(S);

Total_variable_num=0;
%x location
state_variable_location(:,1)=1:T:state_size*T;
state_variable_location(:,2)=[state_variable_location(2:end,1)-1;state_size*T];
state_variable_length=state_size*T;
Total_variable_num=Total_variable_num+state_size*T;
%p
power_variable_location(:,1)=state_variable_location(:,1)+state_size*T;
power_variable_location(:,2)=state_variable_location(:,2)+state_size*T;
power_variable_length=state_size*T;
Total_variable_num=Total_variable_num+state_size*T;

%eta
eta_variable_location(:,1)=Total_variable_num+1:T-1:Total_variable_num+state_size*(T-1);
eta_variable_location(:,2)=[eta_variable_location(2:end,1)-1;Total_variable_num+state_size*(T-1)];
eta_variable_length=state_size*(T-1);
Total_variable_num=Total_variable_num+state_size*(T-1);

%kesi
kesi_variable_location(:,1)=Total_variable_num+1;
kesi_variable_location(:,2)=Total_variable_num+T;
kesi_variable_length=T;
Total_variable_num=Total_variable_num+kesi_variable_length;


index_appliance=[];
for i=1:N
    index_appliance=[index_appliance;i*ones(S(i),1)];
end

penalty_temp1 = C_start*Omega';
penalty_temp2 = reshape(repmat(penalty_temp1,T-1, 1),1,state_size*(T-1));

if(test_day_num>=1)
    penlty_s=repmat(penlty_s,1,test_day_num);
    if(horizion_divide==1)
        penlty_s=penlty_s(:,horizon_windows_index);
        penlty_l=repmat(penlty_l,1,T_origin);
        penlty_l=penlty_l(:,horizon_windows_index);
    else
        penlty_l=repmat(penlty_l,1,T);
    end

else
    penlty_s=penlty_s(:,1:size(penlty_s,2)*test_day_num);
    if(horizion_divide==1)
        penlty_s=penlty_s(:,horizon_windows_index);
        penlty_l=repmat(penlty_l,1,T_origin);
        penlty_l=penlty_l(:,horizon_windows_index);
    else
        penlty_l=repmat(penlty_l,1,T);
    end

end

    penlty_s=(1-penlty_s).*penlty_l;
    penlty_s=reshape(C_run*penlty_s',1,state_size*T);

%quadr term

%the sum of squared differences
H=[];
% H_temp=[];
% for i=1:state_size
%     H_temp=[H_temp,sparse([1:T],[1:T],ones(1,T),T,T)];
% end
% for i=1:state_size
%     H=[H;sparse(T,state_variable_length),H_temp,sparse(T,eta_variable_length)];
% end
%
% H=[sparse(state_variable_length,Total_variable_num);H;sparse(eta_variable_length,Total_variable_num)];



%һ����

% f = [penlty_s, -2*reshape(repmat(P_Sum,1,state_size),power_variable_length,1)', penalty_temp2];
f = [penlty_s, sparse(1,power_variable_length), penalty_temp2,ones(1,kesi_variable_length)];
%��С�ʱ��Լ��
Aineq_min_active_time_constraint=[];
bineq_min_active_time_constraint=[];

for i=1:state_size
    state_vari_location=state_variable_location(i,1):state_variable_location(i,2);
    if(State_Limit(i)>1)
        if(State_Limit(i)>T)
            State_Limit(i)=T;
        end
        for j=1:State_Limit(i)-1
            x_t_1_location_row=1:T-j-1;
            x_t_1_location_col=state_vari_location(1:T-j-1);
            x_t_1_location_value=-1*ones(1,T-j-1);
            
            x_t_location_row=1:T-j-1;
            x_t_location_col=state_vari_location(2:T-j);
            x_t_location_value=ones(1,T-j-1);
            
            x_tao_location_row=1:T-j-1;
            x_tao_location_col=state_vari_location(j+2:T);
            x_tao_location_value=-1*ones(1,T-j-1);
            
            row_location=[x_t_1_location_row,x_t_location_row,x_tao_location_row];
            col_location=[x_t_1_location_col,x_t_location_col,x_tao_location_col];
            coefficient_value=[x_t_1_location_value,x_t_location_value,x_tao_location_value];
            
            constraint_min_active_time=sparse(row_location,col_location,coefficient_value,T-j-1,Total_variable_num);
            Aineq_min_active_time_constraint=[Aineq_min_active_time_constraint;constraint_min_active_time];
        end
    end
end
bineq_min_active_time_constraint=sparse(size(Aineq_min_active_time_constraint,1),1);


%���ʱ���Լ��
Aineq_power_bound_constraint=[];
bineq_power_bound_constraint=[];

%Max bound
x_location_row=1:state_variable_length;
x_location_col=1:state_variable_length;
x_value=-1*reshape(repmat(P_top,1,T)',state_size*T,1);

p_location_row=1:state_variable_length;
p_location_col=state_variable_length+1:state_variable_length+power_variable_length;
p_value=ones(state_variable_length,1);

row_location=[x_location_row,p_location_row];
col_location=[x_location_col,p_location_col];
coefficient_value=[x_value;p_value];

Aineq_power_bound_constraint=[Aineq_power_bound_constraint;sparse(row_location,col_location,coefficient_value,state_variable_length,Total_variable_num)];
bineq_power_bound_constraint=[bineq_power_bound_constraint;sparse(state_variable_length,1)];

%Min bound
x_location_row=1:state_variable_length;
x_location_col=1:state_variable_length;
x_value=reshape(repmat(P_bottom,1,T)',state_size*T,1);

p_location_row=1:state_variable_length;
p_location_col=state_variable_length+1:state_variable_length+power_variable_length;
p_value=-1*ones(state_variable_length,1);

row_location=[x_location_row,p_location_row];
col_location=[x_location_col,p_location_col];
coefficient_value=[x_value,p_value];

Aineq_power_bound_constraint=[Aineq_power_bound_constraint;sparse(row_location,col_location,coefficient_value,state_variable_length,Total_variable_num)];
bineq_power_bound_constraint=[bineq_power_bound_constraint;sparse(state_variable_length,1)];


%״̬ת��Լ��
Aineq_constraint_state_transition=[];
bineq_constraint_state_transition=[];

for i=1:N
    [row_index,col_index]=find(Transition_model{i}==0);
    if(~isempty(row_index))
        appliance_index=find(index_appliance==i);
        for j=1:length(row_index)
            state_location_col=[state_variable_location(appliance_index(row_index(j)),1):state_variable_location(appliance_index(row_index(j)),2)-1];
            constraint_state_transition=sparse([1:T-1],state_location_col,ones(1,T-1),T-1,Total_variable_num);
            
            state_location_col=[state_variable_location(appliance_index(col_index(j)),1)+1:state_variable_location(appliance_index(col_index(j)),2)];
            constraint_state_transition=constraint_state_transition+sparse([1:T-1],state_location_col,ones(1,T-1),T-1,Total_variable_num);
            Aineq_constraint_state_transition=[Aineq_constraint_state_transition;constraint_state_transition];
            bineq_constraint_state_transition=[bineq_constraint_state_transition;ones(T-1,1)];
        end
    end
end

%Multiple States Selected Constraints
Aineq_Multiple_States_Selected_Constraints=[];
bineq_Multiple_States_Selected_Constraints=[];

Aeq_Multiple_States_Selected_Constraints=[];
beq_Multiple_States_Selected_Constraints=[];

for i=1:N
    if(alway_on_matri(i)==1)
        appliance_index=find(index_appliance==i);
        state_location_row=[];
        state_location_col=[];
        for j=1:length(appliance_index)
            state_location_row=[state_location_row,1:T];
            state_location_col=[state_location_col,state_variable_location(appliance_index(j),1):state_variable_location(appliance_index(j),2)];
        end
        Aeq_Multiple_States_Selected_Constraints=[Aeq_Multiple_States_Selected_Constraints;...
            sparse(state_location_row,state_location_col,ones(1,size(state_location_col,2)),T,Total_variable_num)];
        beq_Multiple_States_Selected_Constraints=[beq_Multiple_States_Selected_Constraints;ones(T,1)];
    else
        appliance_index=find(index_appliance==i);
        state_location_row=[];
        state_location_col=[];
        for j=1:length(appliance_index)
            state_location_row=[state_location_row,1:T];
            state_location_col=[state_location_col,state_variable_location(appliance_index(j),1):state_variable_location(appliance_index(j),2)];
        end
        Aineq_Multiple_States_Selected_Constraints=[Aineq_Multiple_States_Selected_Constraints;...
            sparse(state_location_row,state_location_col,ones(1,size(state_location_col,2)),T,Total_variable_num)];
        bineq_Multiple_States_Selected_Constraints=[bineq_Multiple_States_Selected_Constraints;ones(T,1)];
    end
end


%Difference Constraints
Aineq_difference_constraints=[];
bineq_difference_constraints=[];
%
power_location_row=[];
power_location_col=[];
power_location_value=[];
for i=1:state_size
    power_location_row=[power_location_row,1:T];
    power_location_col=[power_location_col,power_variable_location(i,1):power_variable_location(i,2)];
    power_location_value=[power_location_value,-1*ones(1,T)];
end

kesi_location_row=1:T;
kesi_location_col=kesi_variable_location(1):kesi_variable_location(2);
kesi_location_value=-1*ones(1,T);

var_location_row=[power_location_row,kesi_location_row];
var_location_col=[power_location_col,kesi_location_col];
var_location_value=[power_location_value,kesi_location_value];

Aineq_difference_constraints=[Aineq_difference_constraints;sparse(var_location_row,var_location_col,var_location_value,T,Total_variable_num)];
bineq_difference_constraints=[bineq_difference_constraints;-1*P_Sum];


power_location_row=[];
power_location_col=[];
power_location_value=[];
for i=1:state_size
    power_location_row=[power_location_row,1:T];
    power_location_col=[power_location_col,power_variable_location(i,1):power_variable_location(i,2)];
    power_location_value=[power_location_value,ones(1,T)];
end

kesi_location_row=1:T;
kesi_location_col=kesi_variable_location(1):kesi_variable_location(2);
kesi_location_value=-1*ones(1,T);

var_location_row=[power_location_row,kesi_location_row];
var_location_col=[power_location_col,kesi_location_col];
var_location_value=[power_location_value,kesi_location_value];

Aineq_difference_constraints=[Aineq_difference_constraints;sparse(var_location_row,var_location_col,var_location_value,T,Total_variable_num)];
bineq_difference_constraints=[bineq_difference_constraints;P_Sum];


%plenty term
Aineq_plenty_constraints=[];
bineq_plenty_constraints=[];

for i=1:state_size
    x_t_1_location_row=1:T-1;
    x_t_1_location_col=state_variable_location(i,1):state_variable_location(i,2)-1;
    x_t_1_location_value=-1*ones(1,T-1);
    
    x_t_location_row=1:T-1;
    x_t_location_col=state_variable_location(i,1)+1:state_variable_location(i,2);
    x_t_location_value=ones(1,T-1);
    
    eta_location_row=1:T-1;
    eta_location_col=eta_variable_location(i,1):eta_variable_location(i,2);
    eta_location_value=-1*ones(1,T-1);
    
    var_location_row=[x_t_1_location_row,x_t_location_row,eta_location_row];
    var_location_col=[x_t_1_location_col,x_t_location_col,eta_location_col];
    var_location_value=[x_t_1_location_value,x_t_location_value,eta_location_value];
    
    Aineq_plenty_constraints=[Aineq_plenty_constraints;sparse(var_location_row,var_location_col,var_location_value,T-1,Total_variable_num)];
    bineq_plenty_constraints=[bineq_plenty_constraints;sparse(T-1,1)];
    
    %%%%
    x_t_1_location_row=1:T-1;
    x_t_1_location_col=state_variable_location(i,1):state_variable_location(i,2)-1;
    x_t_1_location_value=ones(1,T-1);
    
    x_t_location_row=1:T-1;
    x_t_location_col=state_variable_location(i,1)+1:state_variable_location(i,2);
    x_t_location_value=-1*ones(1,T-1);
    
    eta_location_row=1:T-1;
    eta_location_col=eta_variable_location(i,1):eta_variable_location(i,2);
    eta_location_value=-1*ones(1,T-1);
    
    var_location_row=[x_t_1_location_row,x_t_location_row,eta_location_row];
    var_location_col=[x_t_1_location_col,x_t_location_col,eta_location_col];
    var_location_value=[x_t_1_location_value,x_t_location_value,eta_location_value];
    
    Aineq_plenty_constraints=[Aineq_plenty_constraints;sparse(var_location_row,var_location_col,var_location_value,T-1,Total_variable_num)];
    bineq_plenty_constraints=[bineq_plenty_constraints;sparse(T-1,1)];
    
end


Aineq=[Aineq_constraint_state_transition;Aineq_difference_constraints;Aineq_min_active_time_constraint;Aineq_Multiple_States_Selected_Constraints;Aineq_power_bound_constraint;Aineq_plenty_constraints];
bineq=[bineq_constraint_state_transition;bineq_difference_constraints;bineq_min_active_time_constraint;bineq_Multiple_States_Selected_Constraints;bineq_power_bound_constraint;bineq_plenty_constraints];

Aeq=[Aeq_Multiple_States_Selected_Constraints];
beq=[beq_Multiple_States_Selected_Constraints];


    ctype = '';
    ctype(1:state_size*T) = 'C';
    ctype(state_size*T+1:Total_variable_num) = 'C';
    lb = sparse(Total_variable_num, 1);
    ub = [ones(state_size*T, 1);reshape(repmat(P_top,1,T)',state_size*T,1);inf*ones(Total_variable_num-state_variable_length-power_variable_length,1)];
    
    model.Q=H;
    model.f = f;
    model.Aineq = Aineq;
    model.bineq = bineq;
    model.Aeq = Aeq;
    model.beq = beq;
    model.lb=lb;
    model.ub=ub;
    model.ctype=ctype;
    model.binary_var_location=1:state_size*T;
    model.power_variable_location=state_variable_length+1:state_variable_length+state_size*T;
    model.state_var_location=state_variable_location;
    model.power_var_location=power_variable_location;
    model.eta_var_location=eta_variable_location;
    model.kesi_var_location=kesi_variable_location;
    model.error_variable_location=Total_variable_num-T:Total_variable_num;
    if(horizion_divide==0)
    [result] = solve(model,0.005,1000);
    init_time=result.runtime;
    end
    
    ctype(1:state_size*T) = 'B';
    model.ctype=ctype;

%NS
model_NS.Q=H;
model_NS.f = f;
model_NS.Aineq = [Aineq_difference_constraints;Aineq_power_bound_constraint;Aineq_plenty_constraints];
model_NS.bineq = [bineq_difference_constraints;bineq_power_bound_constraint;bineq_plenty_constraints];
model_NS.Aeq = [];
model_NS.beq = [];
model_NS.lb=lb;
model_NS.ub=ub;
model_NS.ctype=ctype;

model.model_NS=model_NS;


%% model partition
model_partition={};
f_patition={};

Aineq_constraint_state_transition_partition={};
bineq_constraint_state_transition_partition={};

Aineq_difference_constraints_partition={};
bineq_difference_constraints_partition={};

Aineq_min_active_time_constraint_partition={};
bineq_min_active_time_constraint_partition={};

Aineq_Multiple_States_Selected_Constraints_partition={};
bineq_Multiple_States_Selected_Constraints_partition={};

Aineq_power_bound_constraint_partition={};
bineq_power_bound_constraint_partition={};

Aeq_Multiple_States_Selected_Constraints_partition={};
beq_Multiple_States_Selected_Constraints_partition={};

Aineq_plenty_constraints_partition={};
bineq_plenty_constraints_partition={};

for i=1:N
    [index_i]=find(index_appliance==i);
    x_partition_location_index=[];
    eta_partition_location_index=[];
    kesi_partition_location_index=[];
    
    power_partition_location_index=state_size*T+1:2*state_size*T;
    subpower_partition_location_index=power_partition_location_index;
    kesi_partition_location_index=kesi_variable_location(1,1):kesi_variable_location(1,2);
    for j=1:length(index_i)
        x_partition_location_index=[x_partition_location_index,state_variable_location(index_i(j),1):state_variable_location(index_i(j),2)];
        eta_partition_location_index=[eta_partition_location_index,eta_variable_location(index_i(j),1):eta_variable_location(index_i(j),2)];
        subpower_partition_location_index(power_variable_location(index_i(j),1)<=subpower_partition_location_index&subpower_partition_location_index<=power_variable_location(index_i(j),2))=[];
    end

    
    var_partition_location=[x_partition_location_index,power_partition_location_index,eta_partition_location_index,kesi_partition_location_index];
    %
    subvar_partition_location=[x_partition_location_index,subpower_partition_location_index,eta_partition_location_index,kesi_partition_location_index];
    
    couple_subvar=[subpower_partition_location_index,kesi_partition_location_index];
    
    couple_var=[power_partition_location_index,kesi_partition_location_index];
    nonCouple_var=[x_partition_location_index,eta_partition_location_index];
    
    x_location_in_partition=1:length(x_partition_location_index);
    power_location_in_partition=length(x_partition_location_index)+1:length(x_partition_location_index)+length(power_partition_location_index);
    eta_location_in_partition=length(x_partition_location_index)+length(power_partition_location_index)+1:length(x_partition_location_index)+length(power_partition_location_index)+length(eta_partition_location_index);
    kesi_location_in_partition=length(x_partition_location_index)+length(power_partition_location_index)+length(eta_partition_location_index)+1:length(x_partition_location_index)+length(power_partition_location_index)+length(eta_partition_location_index)+length(kesi_partition_location_index);
    
    couple_var_in_partition=[power_location_in_partition,kesi_location_in_partition];
    nonCouple_var_in_partition=[x_location_in_partition,eta_location_in_partition];
    
      [subpower_location_in_power]=find(ismember(power_partition_location_index,subpower_partition_location_index)==1);
      
    subpower_location_in_partition=subpower_location_in_power+length(x_partition_location_index);
 
    
        couple_subvar_in_partition=[subpower_location_in_partition,kesi_location_in_partition];
            subvar_in_couple=[subpower_location_in_power,kesi_partition_location_index-2*state_size*T-eta_variable_length+length(power_partition_location_index)];

    %objective patition
    f_patition{i}=f(var_partition_location);
    
    lb_partition{i}=lb(var_partition_location);
    ub_partition{i}=ub(var_partition_location);
    
    ctype_patition{i}=ctype(var_partition_location);
    %Aineq_constraint_state_transition
    if(~isempty(Aineq_constraint_state_transition))
        [index_row_patition,index_col_patition]=find(Aineq_constraint_state_transition(:,var_partition_location)~=0);
        index_row_patition=unique(index_row_patition);
        
        Aineq_constraint_state_transition_partition{i}=Aineq_constraint_state_transition(index_row_patition,var_partition_location);
        bineq_constraint_state_transition_partition{i}=bineq_constraint_state_transition(index_row_patition);
    else
        Aineq_constraint_state_transition_partition{i}=[];
        bineq_constraint_state_transition_partition{i}=[];
    end
    %Aineq_difference_constraints
    if(~isempty(Aineq_difference_constraints))
        [index_row_patition,index_col_patition]=find(Aineq_difference_constraints(:,var_partition_location)~=0);
        index_row_patition=unique(index_row_patition);
        
        Aineq_difference_constraints_partition{i}=Aineq_difference_constraints(index_row_patition,var_partition_location);
        bineq_difference_constraints_partition{i}=bineq_difference_constraints(index_row_patition);
    else
        Aineq_difference_constraints_partition{i}=[];
        bineq_difference_constraints_partition{i}=[];
    end
    
    
    %Aineq_min_active_time_constraint
    if(~isempty(Aineq_min_active_time_constraint))
        [index_row_patition,index_col_patition]=find(Aineq_min_active_time_constraint(:,var_partition_location)~=0);
        index_row_patition=unique(index_row_patition);
        
        Aineq_min_active_time_constraint_partition{i}=Aineq_min_active_time_constraint(index_row_patition,var_partition_location);
        bineq_min_active_time_constraint_partition{i}=bineq_min_active_time_constraint(index_row_patition);
    else
        Aineq_min_active_time_constraint_partition{i}=[];
        bineq_min_active_time_constraint_partition{i}=[];
    end
    
    
    
    %Aineq_Multiple_States_Selected_Constraints
    if(~isempty(Aineq_Multiple_States_Selected_Constraints))
        [index_row_patition,index_col_patition]=find(Aineq_Multiple_States_Selected_Constraints(:,var_partition_location)~=0);
        index_row_patition=unique(index_row_patition);
        
        Aineq_Multiple_States_Selected_Constraints_partition{i}=Aineq_Multiple_States_Selected_Constraints(index_row_patition,var_partition_location);
        bineq_Multiple_States_Selected_Constraints_partition{i}=bineq_Multiple_States_Selected_Constraints(index_row_patition);
    else
        Aineq_Multiple_States_Selected_Constraints_partition{i}=[];
        bineq_Multiple_States_Selected_Constraints_partition{i}=[];
    end
    
    
    %Aineq_power_bound_constraint
    if(~isempty(Aineq_power_bound_constraint))
        [index_row_patition,index_col_patition]=find(Aineq_power_bound_constraint(:,x_partition_location_index)~=0);
        index_row_patition=unique(index_row_patition);
        
        Aineq_power_bound_constraint_partition{i}=Aineq_power_bound_constraint(index_row_patition,var_partition_location);
        bineq_power_bound_constraint_partition{i}=bineq_power_bound_constraint(index_row_patition);
    else
        Aineq_power_bound_constraint_partition{i}=[];
        bineq_power_bound_constraint_partition{i}=[];
    end
    
    %Aineq_plenty_constraints
    if(~isempty(Aineq_plenty_constraints))
        [index_row_patition,index_col_patition]=find(Aineq_plenty_constraints(:,var_partition_location)~=0);
        index_row_patition=unique(index_row_patition);
        
        Aineq_plenty_constraints_partition{i}=Aineq_plenty_constraints(index_row_patition,var_partition_location);
        bineq_plenty_constraints_partition{i}=bineq_plenty_constraints(index_row_patition);
    else
        Aineq_plenty_constraints_partition{i}=[];
        bineq_plenty_constraints_partition{i}=[];
    end
    
    
    %Aeq_Multiple_States_Selected_Constraints
    if(~isempty(Aeq_Multiple_States_Selected_Constraints))
        [index_row_patition,index_col_patition]=find(Aeq_Multiple_States_Selected_Constraints(:,var_partition_location)~=0);
        index_row_patition=unique(index_row_patition);
        
        Aeq_Multiple_States_Selected_Constraints_partition{i}=Aeq_Multiple_States_Selected_Constraints(index_row_patition,var_partition_location);
        beq_Multiple_States_Selected_Constraints_partition{i}=beq_Multiple_States_Selected_Constraints(index_row_patition);
    else
        Aeq_Multiple_States_Selected_Constraints_partition{i}=[];
        beq_Multiple_States_Selected_Constraints_partition{i}=[];
    end
    
    
    model_partition{i}.f=f_patition{i};
    model_partition{i}.Aineq=[Aineq_constraint_state_transition_partition{i};Aineq_difference_constraints_partition{i};Aineq_min_active_time_constraint_partition{i};Aineq_Multiple_States_Selected_Constraints_partition{i};Aineq_power_bound_constraint_partition{i};Aineq_plenty_constraints_partition{i}];
    model_partition{i}.bineq=[bineq_constraint_state_transition_partition{i};bineq_difference_constraints_partition{i};bineq_min_active_time_constraint_partition{i};bineq_Multiple_States_Selected_Constraints_partition{i};bineq_power_bound_constraint_partition{i};bineq_plenty_constraints_partition{i}];
    model_partition{i}.Aeq=[Aeq_Multiple_States_Selected_Constraints_partition{i}];
    model_partition{i}.beq=[beq_Multiple_States_Selected_Constraints_partition{i}];
     model_partition{i}.lb=lb_partition{i};
     model_partition{i}.ub=ub_partition{i};
     model_partition{i}.ctype=ctype_patition{i};
      model_partition{i}.Coupling_variable_location=couple_var;
      model_partition{i}.nonCoupling_variable_location=nonCouple_var;
      model_partition{i}.Coupling_variable_in_partition_location=couple_var_in_partition;
      model_partition{i}.nonCoupling_variable_in_partition_location=nonCouple_var_in_partition;
      model_partition{i}.x_location_partition=x_partition_location_index;
      model_partition{i}.couple_subvar_in_partition_location=couple_subvar_in_partition;
      model_partition{i}.couple_subvar_location=couple_subvar;
      model_partition{i}.var_partition_location=var_partition_location;
      model_partition{i}.subvar_in_couple=subvar_in_couple;
end

model.partition=model_partition;
model.couple_variable=[power_location_col,kesi_location_col];
model.Aineq_couple_constraint=Aineq_difference_constraints;
model.bineq_couple_constraint=bineq_difference_constraints;
model.Aineq_noncouple_constraint=[Aineq_constraint_state_transition;Aineq_min_active_time_constraint;Aineq_Multiple_States_Selected_Constraints;Aineq_power_bound_constraint;Aineq_plenty_constraints];
model.bineq_noncouple_constraint=[bineq_constraint_state_transition;bineq_min_active_time_constraint;bineq_Multiple_States_Selected_Constraints;bineq_power_bound_constraint;bineq_plenty_constraints];
model.Aeq_noncouple_constraint=[Aeq_Multiple_States_Selected_Constraints];
model.beq_noncouple_constraint=[beq_Multiple_States_Selected_Constraints];

%% ���ɳ�ʼ��

x=sparse(state_variable_length,1);
p=sparse(power_variable_length,1);
eta=sparse(eta_variable_length,1);
kesi=sparse(kesi_variable_length,1);

for i=1:state_size
    if(alway_on_matri(index_appliance(i))==1)
        [index_state_appliance]=find(index_appliance==index_appliance(i));
        [index_state]=find(i==index_state_appliance);
        if(index_state==1)
            x(state_variable_location(index_appliance(i),1):state_variable_location(index_appliance(i),2))=1;
            p(state_variable_location(index_appliance(i),1):state_variable_location(index_appliance(i),2))=P(i);
        end
    end
end
solution=[x;p;eta;kesi];

if(horizion_divide==0)
    init_x=result.x;
    % init_x=solution;
    model.init_x=init_x;
    model.init_time=init_time;
end
end