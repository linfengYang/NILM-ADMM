function [results] = function_p_norm_box_ADMM_horizon_RD_parall(Pending_model)
%FUNCTION_P_NORM_BOX_ADMM �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
p=2;
gamma=1;
log=[];
%full
H=Pending_model.total.Q;
f = Pending_model.total.f';
Aineq = Pending_model.total.Aineq;
bineq = Pending_model.total.bineq;
Aeq = Pending_model.total.Aeq;
beq = Pending_model.total.beq;
binary_var_location=Pending_model.total.binary_var_location;
binary_var_num=length(binary_var_location);
lb=Pending_model.total.lb;
ub=Pending_model.total.ub;
windows_index=Pending_model.windows_index;
if(~isempty(strfind(Pending_model.total.ctype,'B')))
 ctype=strrep(Pending_model.total.ctype,'B','C');
else
    ctype=Pending_model.total.ctype;
end

%partition
x_horizon_partition_location={};
binary_horizon_partition_location={};
p_horizon_partition_location={};
eta_horizon_partition_location={};
kesi_horizon_partition_location={};
windows_index_t_1=windows_index-1;
windows_index_t_1(:,1)=windows_index_t_1(:,1)+1;
windows_index_t_1(1,1)=1;
A1_augment_partition={};
for i=1:size(windows_index,1)
    
    binary_horizon_partition_location{i}=[];
    p_horizon_partition_location{i}=[];
    eta_horizon_partition_location{i}=[];
    kesi_horizon_partition_location{i}=[];
    
    for j=1:size(Pending_model.total.state_var_location,1)
        %state var
        index_location=Pending_model.total.state_var_location(j,1):Pending_model.total.state_var_location(j,2);
        binary_horizon_partition_location{i}=[binary_horizon_partition_location{i},index_location(windows_index(i,1):windows_index(i,2))];
        
        %power
         index_location=Pending_model.total.power_var_location(j,1):Pending_model.total.power_var_location(j,2);
         p_horizon_partition_location{i}=[p_horizon_partition_location{i},index_location(windows_index(i,1):windows_index(i,2))];
         
         %eta  
         index_location=Pending_model.total.eta_var_location(j,1):Pending_model.total.eta_var_location(j,2);
         eta_horizon_partition_location{i}=[eta_horizon_partition_location{i},index_location(windows_index_t_1(i,1):windows_index_t_1(i,2))];
    end
    
    %kesi
    index_location=Pending_model.total.kesi_var_location(1,1):Pending_model.total.kesi_var_location(1,2);
    kesi_horizon_partition_location{i}=index_location(windows_index(i,1):windows_index(i,2));
    
    x_horizon_partition_location{i}=[binary_horizon_partition_location{i},p_horizon_partition_location{i},eta_horizon_partition_location{i},kesi_horizon_partition_location{i}];
    x_binary_horizon_partition_location{i}=1:length(binary_horizon_partition_location{i});
    x_p_horizon_partition_location{i}=length(binary_horizon_partition_location{i})+1:length(binary_horizon_partition_location{i})+length(p_horizon_partition_location{i});
    x_eta_horizon_partition_location{i}=length(binary_horizon_partition_location{i})+length(p_horizon_partition_location{i})+1:length(binary_horizon_partition_location{i})+length(p_horizon_partition_location{i})+length(eta_horizon_partition_location{i});
    x_kesi_horizon_partition_location{i}=length(binary_horizon_partition_location{i})+length(p_horizon_partition_location{i})+length(eta_horizon_partition_location{i})+1:length(binary_horizon_partition_location{i})+length(p_horizon_partition_location{i})+length(eta_horizon_partition_location{i})+length(kesi_horizon_partition_location{i});
    
    if(~isempty(strfind(Pending_model.partition{i}.ctype,'B')))
        Pending_model.partition{i}.ctype=strrep(Pending_model.partition{i}.ctype,'B','C');
    else
        Pending_model.partition{i}=Pending_model.partition{i};
    end
    
    A1_augment_partition{i}=[sparse([1:length(binary_horizon_partition_location{i})],[1:length(binary_horizon_partition_location{i})],ones(1,length(binary_horizon_partition_location{i})),length(binary_horizon_partition_location{i}),length(binary_horizon_partition_location{i})),...
        sparse(length(binary_horizon_partition_location{i}),length(x_horizon_partition_location{i})-length(binary_horizon_partition_location{i}))];
end
A2_augment_partition=A1_augment_partition;


% x=y1
A1=sparse([1:binary_var_num],[1:binary_var_num],ones(1,binary_var_num),binary_var_num,binary_var_num);
%x=y2
A2=A1;

%Augment
A1_augment=[A1,sparse(size(A1,1),length(f)-binary_var_num)];
A2_augment=A1_augment;



y1_num=binary_var_num;%x�ĸ��Ʊ��� 0<=y1<=1
y2_num=binary_var_num;%x�ĸ��Ʊ��� ||y2-1/2||_2 ^2=n/(2^2)
y3_num=size(Aineq,1);%�������� Aineq*x+y3=bineq  y3>=0
z1_num=size(Aeq,1);%��ż���� eq
z2_num=size(Aineq,1);%��ż���� ineq
z3_num=binary_var_num;%��ż���� x=y1
z4_num=binary_var_num;%��ż���� x=y2

ro_1=1000;%eq constraint pently 
ro_2=1000;%ineq constraint pently 
ro_3=1;%x=y1 constraint pently 
ro_4=15;%x=y2 constraint pently 

ro_1_max=10000;%eq constraint pently 
ro_2_max=10000;%ineq constraint pently 
ro_3_max=10000;%x=y1 constraint pently 
ro_4_max=10000;%x=y2 constraint pently 

miu_ro=0.05;

iter=0;
runtime=0;

while(1)
    tic
    if(iter==0)
        %init k=0
        if(isfield(Pending_model.total,'init_x'))
            x_binary_k=Pending_model.total.init_x(binary_var_location);
            x_conti_k=Pending_model.total.init_x(binary_var_num+1:length(f));
            y1_k=sparse(y1_num,1);
            y2_k=sparse(y2_num,1);
            y3_k=sparse(y3_num,1);
            z1_k=sparse(z1_num,1);
            z2_k=sparse(z2_num,1);
            z3_k=sparse(z3_num,1);
            z4_k=sparse(z4_num,1);
        else
            x_binary_k=ones(binary_var_num,1);
            x_conti_k=ones(length(f)-binary_var_num,1);
            y1_k=sparse(y1_num,1);
            y2_k=sparse(y2_num,1);
            y3_k=sparse(y3_num,1);
            z1_k=sparse(z1_num,1);
            z2_k=sparse(z2_num,1);
            z3_k=sparse(z3_num,1);
            z4_k=sparse(z4_num,1);
        end
                obj_k=0;
    else
        ro_1=min((1+miu_ro)*ro_1,ro_1_max);%eq constraint pently
        ro_2=min((1+miu_ro)*ro_2,ro_2_max);%ineq constraint pently
        ro_3=min((1+miu_ro)*ro_3,ro_3_max);%x=y1 constraint pently
        ro_4=min((1+miu_ro)*ro_4,ro_4_max);%x=y2 constraint pently

    end





obj=obj_k;
x_binary=x_binary_k;
x_conti=x_conti_k;
y1=y1_k;
y2=y2_k;
y3=y3_k;
z1=z1_k;
z2=z2_k;
z3=z3_k;
z4=z4_k;
%% update y1

% y1_k=min(ones(binary_var_num,1),max(sparse(binary_var_num,1),A1*x_binary+(1/ro_3)*z3));



%% update y2
y2_k_temp=A2*x_binary+(1/ro_4)*z4;
y2_k_temp=y2_k_temp-1/2;
y2_k=(power(binary_var_num,1/p)/2)*(y2_k_temp/norm(y2_k_temp,p))+1/2;



%% update y3
y3_k_temp=bineq-(1/ro_2)*z2-Aineq*[x_binary;x_conti];
y3_k=max(0,y3_k_temp);



%% update x

% CG_A=ro_1*Aeq'*Aeq+ro_2*Aineq'*Aineq+ro_3*A1_augment'*A1_augment+ro_4*A2_augment'*A2_augment;
% CG_b=ro_1*Aeq'*beq+ro_2*Aineq'*(bineq-y3_k)+ro_3*A1_augment'*y1_k+ro_4*A2_augment'*y2_k...
%     -f-Aeq'*z1-Aineq'*z2-A1_augment'*z3-A2_augment'*z4;
% 
% [x] = function_CG(CG_A, CG_b, [x_binary;x_conti]);
%RD
RD_alpha=sparse(length(x_binary),1);
x_up_location=find(x_binary>=0.5);
x_low_location=find(x_binary<0.5);


RD_alpha(x_up_location)=2*(x_binary(x_up_location)-0.5);
RD_alpha(x_low_location)=2*(0.5-x_binary(x_low_location));

RD_alpha(x_up_location)=-1*RD_alpha(x_up_location);

f_RD_alpha=sparse(length(f),1);
f_RD_alpha(binary_var_location)=RD_alpha;
%IRI
if(iter==0)
W=10000;
else
    W=power(10,floor(log10(obj_k)));
end

IRI_eco=W*(1-2*x_binary);
f_IRI_eco=sparse(length(f),1);
f_IRI_eco(binary_var_location)=IRI_eco;

x=sparse(length(f),1);

QP_H=[];
parfor i=1:size(windows_index,1)
   model_QP{i}=[];
   x_temple{i}=[]
   QP_f=Pending_model.partition{i}.f'+(z4(binary_horizon_partition_location{i})'*A2_augment_partition{i})'+W*f_RD_alpha(x_horizon_partition_location{i})+f_IRI_eco(x_horizon_partition_location{i});%-(ro_4*y2_k(binary_horizon_partition_location{i})'*A2_augment_partition{i})';%z3'*A1_augment+   ro_3*y1_k'*A1_augment+
    
   model_QP{i}.Q=QP_H;
   model_QP{i}.f=QP_f;
   model_QP{i}.Aineq=Pending_model.partition{i}.Aineq;
    model_QP{i}.bineq=Pending_model.partition{i}.bineq;
    model_QP{i}.Aeq=Pending_model.partition{i}.Aeq;
    model_QP{i}.beq=Pending_model.partition{i}.beq;
    model_QP{i}.ctype=Pending_model.partition{i}.ctype;
    model_QP{i}.lb=Pending_model.partition{i}.lb;   
    model_QP{i}.ub=Pending_model.partition{i}.ub;
    [result] = solve(model_QP{i},0.001,1000);
    x_temple{i}=result.x;
end
for i=1:size(windows_index,1)
    x(x_horizon_partition_location{i})=x_temple{i};
end

x_binary_k=x(binary_var_location);
x_conti_k=x(binary_var_num+1:length(f));
%% update z1
z1_k=z1+gamma*ro_1*(Aeq*x-beq);



%% update z2
z2_k=z2+gamma*ro_2*(Aineq*x-bineq);



%% update z3
% z3_k=z3+ro_3*(x_binary_k-y1_k);


%% update z4
z4_k=z4+ro_4*(x_binary_k-y2_k);



%% stopping criteria
delta_x_binary=abs(x_binary_k-x_binary);
% delta_x_y1=abs(x_binary_k-y1_k);
delta_x_y2=abs(x_binary_k-y2_k);

obj_k=f'*x;
delta_obj=abs(obj-obj_k);
iter=iter+1;
runtime=runtime+toc;


disp(sum(delta_x_binary));
% disp(sum(delta_x_y1));
disp(sum(delta_x_y2));
disp(sum(delta_obj));
disp(iter)
disp(runtime)
log=[log;iter,runtime,obj_k,sum(delta_x_binary),sum(delta_x_y2),sum(delta_obj)];
if(delta_x_binary<=0.001&delta_x_y2<=0.01&delta_obj<=0.001)%delta_x_y1<=0.001&
    break;
end

end

results.x=x;
results.runtime=runtime;
results.log=log;
end

