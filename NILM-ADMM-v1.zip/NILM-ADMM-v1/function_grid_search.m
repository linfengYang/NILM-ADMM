function [C_sart,C_run]=function_grid_search(P,P_top, P_bottom, State_Limit , P_data,  Transition_model, Omega,test_data_num,S,test_day_num,validate_data_location,select_appliance_name,penlty_s,penlty_l,state_size,T,N,m1,m2,Total_iter,int_length,always_On_appliance)
P_data=P_data(validate_data_location,:);
P_Sum=sum(P_data,2);
P_test=num2cell(P_data,1);
% if(~isempty(Q_data))
% Q_data=Q_data(validate_data_location,:);
% Q_Sum=sum(Q_data,2);
% else
%     Q_Sum=[];
% end


G1=linspace(0.001,m1,int_length);
G2=linspace(0.001,m2,int_length);


x1_max=-1e10;
x2_max=-1e10;
f_max=-1e10;

for iter=1:Total_iter
    
    for j=1:length(G1)
        for k=1:length(G2)
            
            Input_parameter.P_top=P_top; %功率上界
            Input_parameter.P_bottom=P_bottom; %功率下界
            Input_parameter.P_mid=P; %功率
            Input_parameter.P_bottom=P_bottom; %功率下界
            Input_parameter.State_Limit=State_Limit; %最小活动时间
            Input_parameter.P_Sum=P_Sum;  %总功率
            Input_parameter.Transition_model=Transition_model; %状态转换矩阵
            Input_parameter.Omega=Omega;
            Input_parameter.test_data_num=test_data_num;
            Input_parameter.S=S;
            Input_parameter.test_day_num=test_day_num;
            Input_parameter.penlty_s=penlty_s;
            Input_parameter.penlty_l=penlty_l;
            Input_parameter.C_start=G1(j);
            Input_parameter.C_run=G2(k);
            Input_parameter.alway_on_matri=always_On_appliance;
            [model_EMILP] = function_construct_IP(Input_parameter);
            [result] = function_p_norm_box_ADMM(model_EMILP);
            
            %             [model_EMILP] = function_construction_EMILP(P_top, P_bottom, Q_top, Q_bottom, State_Limit , P_Sum, Q_Sum, P_up, P_down, Q_up, Q_down, Transition_model, Omega,test_data_num,S,test_day_num,penlty_s,penlty_l,G1(j),G2(k));
            
            
            %             [result] = solve(model_EMILP,0.001);
            % [x,fval,exitflag,output]= cplexmiqcp(H,f,Aineq,bineq,Aeq,beq,l,Q,r,sostype,sosind,soswt,lb,ub,ctype,x0,options)
            disp('Optimize done!!');
            x_value=result.x;
            state_size_MILP = sum(S);
            index_appliance_MILP=[];
            for i=1:length(select_appliance_name)
                index_appliance_MILP=[index_appliance_MILP;i*ones(S(i),1)];
            end
            EMILP_x=round(reshape(x_value(1:state_size_MILP*T),T,state_size_MILP));
            % P_value = reshape(x_value(state_size_MILP*T+1:state_size_MILP*T*2, :),T,state_size_MILP); % 取出连续变量Pit的值
            P_value = repmat(P',T,1);
            device_state = x_value(1:state_size_MILP*T, :); % 取出0-1变量Xit的值
            power_appliance=EMILP_x.*P_value;
            Decompose_data = {};
            for  i= 1:N
                index_i=find(index_appliance_MILP==i);
                decompose =sum(power_appliance(:,index_i),2);
                Decompose_data = [Decompose_data; decompose];
            end
            disp('Decompose done!!');
            
            
            x_axis = 1:1:T; % T个点的x座标
            predict_sum = sparse(test_data_num, 1);
            figure(1)          % define figure
            for i = 1:N
                predict_sum = predict_sum+Decompose_data{i};
                subplot(N+2,1,i);     % subplot(x,y,n)x表示显示的行数，y表示列数，n表示第几幅图片
                plot(x_axis, Decompose_data{i}, x_axis, P_data(:,i));
                legend('predict','true');
                title(select_appliance_name{i});
            end
            subplot(N+2,1,N+1);     % subplot(x,y,n)x表示显示的行数，y表示列数，n表示第几幅图片
            plot(x_axis, sparse(T,1), x_axis, abs(P_Sum-predict_sum));
            legend('predict','unknow');
            title('unknow device');
            
            subplot(N+2,1,N+2);     % subplot(x,y,n)x表示显示的行数，y表示列数，n表示第几幅图片
            plot(x_axis, predict_sum, x_axis, P_Sum);
            legend('predict','true');
            title('Total consumption');
            
            [RSE_EMILP, R_square_EMILP, AC_EMILP, h_predict_EMILP, h_true_EMILP, h_error_EMILP,OCC_EMILP,FS_EMILP] = evaluation_func(P_test, Decompose_data,EMILP_x,S,always_On_appliance);
            mean_AC=mean(AC_EMILP);
            if mean_AC>=f_max
                iter
                max_AC=AC_EMILP;
                f_max=mean_AC
                x1_max=G1(j)
                x2_max=G2(k)
            end
        end
    end
    
    G1=linspace(x1_max-x1_max/10,x1_max+x1_max/10,10);
    G2=linspace(x2_max-x2_max/10,x2_max+x2_max/10,10);
    
    
end
C_sart=x1_max;
C_run=x2_max;

end
