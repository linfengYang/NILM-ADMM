function [result] = function_p_norm_box_ADMM_RD(Pending_model)
%FUNCTION_P_NORM_BOX_ADMM �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
p=2;
gamma=1;
log=[];
H=Pending_model.Q;
f = Pending_model.f';
Aineq = Pending_model.Aineq;
bineq = Pending_model.bineq;
Aeq = Pending_model.Aeq;
beq = Pending_model.beq;
binary_var_location=Pending_model.binary_var_location;
binary_var_num=length(binary_var_location);
lb=Pending_model.lb;
ub=Pending_model.ub;
if(~isempty(strfind(Pending_model.ctype,'B')))
 ctype=strrep(Pending_model.ctype,'B','C');
else
    ctype=Pending_model.ctype;
end
% x=y1
A1=sparse([1:binary_var_num],[1:binary_var_num],ones(1,binary_var_num),binary_var_num,binary_var_num);
%x=y2
A2=A1;

%Augment
A1_augment=[A1,sparse(size(A1,1),length(f)-binary_var_num)];
A2_augment=A1_augment;

y1_num=binary_var_num;%x�ĸ��Ʊ��� 0<=y1<=1
y2_num=binary_var_num;%x�ĸ��Ʊ��� ||y2-1/2||_2 ^2=n/(2^2)
y3_num=size(Aineq,1);%�������� Aineq*x+y3=bineq  y3>=0
z1_num=size(Aeq,1);%��ż���� eq
z2_num=size(Aineq,1);%��ż���� ineq
z3_num=binary_var_num;%��ż���� x=y1
z4_num=binary_var_num;%��ż���� x=y2

ro_1=1000;%eq constraint pently 
ro_2=1000;%ineq constraint pently 
ro_3=1;%x=y1 constraint pently 
ro_4=15;%x=y2 constraint pently 

ro_1_max=10000;%eq constraint pently 
ro_2_max=10000;%ineq constraint pently 
ro_3_max=10000;%x=y1 constraint pently 
ro_4_max=10000;%x=y2 constraint pently 

miu_ro=0.05;

iter=0;
runtime=0;

while(1)
    tic
    if(iter==0)
        %init k=0
        if(isfield(Pending_model,'init_x'))
            x_binary_k=Pending_model.init_x(binary_var_location);
            x_conti_k=Pending_model.init_x(binary_var_num+1:length(f));
            y1_k=sparse(y1_num,1);
            y2_k=sparse(y2_num,1);
            y3_k=sparse(y3_num,1);
            z1_k=sparse(z1_num,1);
            z2_k=sparse(z2_num,1);
            z3_k=sparse(z3_num,1);
            z4_k=sparse(z4_num,1);
        else
            x_binary_k=ones(binary_var_num,1);
            x_conti_k=ones(length(f)-binary_var_num,1);
            y1_k=sparse(y1_num,1);
            y2_k=sparse(y2_num,1);
            y3_k=sparse(y3_num,1);
            z1_k=sparse(z1_num,1);
            z2_k=sparse(z2_num,1);
            z3_k=sparse(z3_num,1);
            z4_k=sparse(z4_num,1);
        end
                obj_k=0;
    else
        ro_1=min((1+miu_ro)*ro_1,ro_1_max);%eq constraint pently
        ro_2=min((1+miu_ro)*ro_2,ro_2_max);%ineq constraint pently
        ro_3=min((1+miu_ro)*ro_3,ro_3_max);%x=y1 constraint pently
        ro_4=min((1+miu_ro)*ro_4,ro_4_max);%x=y2 constraint pently

    end





obj=obj_k;
x_binary=x_binary_k;
x_conti=x_conti_k;
y1=y1_k;
y2=y2_k;
y3=y3_k;
z1=z1_k;
z2=z2_k;
z3=z3_k;
z4=z4_k;
%% update y1

% y1_k=min(ones(binary_var_num,1),max(sparse(binary_var_num,1),A1*x_binary+(1/ro_3)*z3));



%% update y2
y2_k_temp=A2*x_binary+(1/ro_4)*z4;
y2_k_temp=y2_k_temp-1/2;
y2_k=(power(binary_var_num,1/p)/2)*(y2_k_temp/norm(y2_k_temp,p))+1/2;



%% update y3
y3_k_temp=bineq-(1/ro_2)*z2-Aineq*[x_binary;x_conti];
y3_k=max(0,y3_k_temp);



%% update x

% CG_A=ro_1*Aeq'*Aeq+ro_2*Aineq'*Aineq+ro_3*A1_augment'*A1_augment+ro_4*A2_augment'*A2_augment;
% CG_b=ro_1*Aeq'*beq+ro_2*Aineq'*(bineq-y3_k)+ro_3*A1_augment'*y1_k+ro_4*A2_augment'*y2_k...
%     -f-Aeq'*z1-Aineq'*z2-A1_augment'*z3-A2_augment'*z4;
% 
% [x] = function_CG(CG_A, CG_b, [x_binary;x_conti]);

%RD
RD_alpha=sparse(length(x_binary),1);
x_up_location=find(x_binary>=0.5);
x_low_location=find(x_binary<0.5);


RD_alpha(x_up_location)=2*(x_binary(x_up_location)-0.5);
RD_alpha(x_low_location)=2*(0.5-x_binary(x_low_location));

RD_alpha(x_up_location)=-1*RD_alpha(x_up_location);

f_RD_alpha=sparse(length(f),1);
f_RD_alpha(binary_var_location)=RD_alpha;
%IRI
if(iter==0)
W=10000;
else
    W=power(10,floor(log10(obj_k)));
end

IRI_eco=W*(1-2*x_binary);
f_IRI_eco=sparse(length(f),1);
f_IRI_eco(binary_var_location)=IRI_eco;

QP_H=[];%(ro_4/2)*A2_augment'*A2_augment;%(ro_3/2)*A1_augment'*A1_augment+(ro_4/2)*A2_augment'*A2_augment;
% QP_f=f+(z4'*A2_augment)'-(ro_4*y2_k'*A2_augment)';%z3'*A1_augment+   ro_3*y1_k'*A1_augment+
QP_f=f+(z4'*A2_augment)'+W*f_RD_alpha+f_IRI_eco;
model_QP.Q=QP_H;
model_QP.f=QP_f;
model_QP.Aineq=Aineq;
model_QP.bineq=bineq;
model_QP.Aeq=Aeq;
model_QP.beq=beq;
model_QP.ctype=ctype;
model_QP.lb=lb;
model_QP.ub=ub;
% model_QP.init_x=[x_binary;x_conti];
% model_QP.ctype(binary_var_location)='B';
[results] = solve(model_QP,0.005,1000);
x=results.x;
% options = optimoptions('linprog','Algorithm','interior-point');
% [x,fval,exitflag,output] = linprog(model_QP.f,model_QP.Aineq,model_QP.bineq,model_QP.Aeq,model_QP.beq,model_QP.lb,model_QP.ub,options);

% x(binary_var_location)=round(result.x(binary_var_location));


x_binary_k=x(binary_var_location);
x_conti_k=x(binary_var_num+1:length(f));
%% update z1
z1_k=z1+gamma*ro_1*(Aeq*x-beq);



%% update z2
z2_k=z2+gamma*ro_2*(Aineq*x-bineq);



%% update z3
% z3_k=z3+ro_3*(x_binary_k-y1_k);


%% update z4
z4_k=z4+ro_4*(x_binary_k-y2_k);



%% stopping criteria
delta_x_binary=abs(x_binary_k-x_binary);
% delta_x_y1=abs(x_binary_k-y1_k);
delta_x_y2=abs(x_binary_k-y2_k);
delta_y2=abs(y2_k-y2);


obj_k=f'*x;
delta_obj=abs(obj-obj_k);
iter=iter+1;
runtime=runtime+toc;

disp('����������');
disp(sum(delta_x_binary));
disp('x��y�Ĳ�');
% disp(sum(delta_x_y1));
disp(sum(delta_x_y2));
disp('Ŀ��ֵ�Ĳ�');
disp(sum(delta_obj));
disp(iter)
disp(runtime)
log=[log;iter,runtime,obj_k,sum(delta_x_binary),sum(delta_x_y2),sum(delta_obj),sum(delta_y2)];
if((delta_x_binary<=0.0001&delta_x_y2<=0.005&delta_obj<=0.001))%delta_x_y1<=0.001&  |iter>1
    break;
end

end

result.x=x;
result.runtime=runtime;
result.log=log;
end

