% CSV����Ԥ����
function [P, P_top, P_bottom, State_Limit, P_test, P_Sum, Transition_model, Omega, P_train,probabilities_On,proportion_used_applicance,State_max_Limit,class_num,Space_division_strategy,windows_index] = DataProcessing_MILP(train_data,test_data,select_device,select_data_type,select_data_Set, S,cluster_id,train_data_num,test_data_num,train_day_num,always_On_appliance,test_day_num)

N= length(select_device);
train_rows=train_data_num;
test_rows=test_data_num;
class_num=S+always_On_appliance-1;
index_appliance=[];
for i=1:N
    index_appliance=[index_appliance;i*ones(class_num(i),1)];
end

P_train = {};
P_test = {};
P_Sum=[];
for i=1:length(select_data_type)
    switch select_data_type{i}
        case 'P'
            eval(strcat('P_train=','train_data.',select_data_Set{1},'.appliance_P;'));
            eval(strcat('P_test=','test_data.',select_data_Set{1},'.appliance_P;'));
            P_Sum=sum(P_test,2);
        otherwise
            warning('no exist this data type!');
    end
end


State_Size = sum(class_num);

P = [];
P_top = [];
P_bottom = [];


% State_Limit = inf*ones(X_Size, 1);
State_Limit = []; %����״̬����С����ʱ��
P_State = {}; % �õ������������

P_State_origin = {}; % ԭʼ����״̬
P_State_sort_origin = {}; % ԭʼ����״̬����
P_State_unsort_origin = {}; % ԭʼ����״̬����
% ����kmeans�������״̬�Ĺ���P, P_Top, P_Bottom

P=[]; P_top=[]; P_bottom=[];
for i = 1:N
    result_Idx=cluster_id(:,i);
    P_top_temp=[];
    P_bottom_temp=[];
    P_temp=[];
    iter_index=1;
    for j=1:S(i)
        P_train_sort=sort(P_train(find(result_Idx==j),i));
        P_top_temp=[P_top_temp;P_train_sort(floor(0.9*length(P_train_sort)))];
        P_bottom_temp=[P_bottom_temp;P_train_sort(ceil(0.1*length(P_train_sort)))];
        P_temp=[P_temp;mean(P_train(find(result_Idx==j),i))];
    end
    P_sort=sort(P_temp);
    for j=1:S(i)
        if(P_sort(j)~=P_temp(j))
            [index_sort]=find(P_temp==P_sort(j));
            
            [index_cluster_1]=find(cluster_id(:,i)==j);
            [index_cluster_2]=find(cluster_id(:,i)==index_sort);
            cluster_id(index_cluster_1,i)=index_sort;
            cluster_id(index_cluster_2,i)=j;
            
            temp=P_temp(j);
            P_temp(j)=P_temp(index_sort);
            P_temp(index_sort)=temp;
            
        end
    end
    if(class_num(i)~=S(i))
        [index_row,index_col]=find(P_temp==min(P_temp));
        if(iter_index==1)
            iter_index=0;
            cluster_id(:,i)=cluster_id(:,i)-1;
        end
        P_temp(index_row)=[];
        P_top_temp(index_row)=[];
        P_bottom_temp(index_row)=[];
        
    end
    P_temp_sort=[];P_top_temp_sort=[];P_bottom_temp_sort=[];
    for k=1:class_num(i)
        [index_row,index_col]=find(P_temp==min(P_temp));
        P_temp_sort(k)=P_temp(index_row);
        P_top_temp_sort(k)=P_top_temp(index_row);
        P_bottom_temp_sort(k)=P_bottom_temp(index_row);
        P_temp(index_row)=[];
        P_top_temp(index_row)=[];
        P_bottom_temp(index_row)=[];
    end
    P=[P;P_temp_sort']; P_top=[P_top;P_top_temp_sort']; P_bottom=[P_bottom;P_bottom_temp_sort'];
end



% ���ô���˼��ȥͳ����С����ʱ�䣬���ڵ�Ŀ����ȥ������
p1=1;
active_time_data=[];
for i = 1:N
    P_temp = cluster_id(:,i);
    for j = 1:class_num(i)
        
        [state_index_row,state_index_col]=find(P_temp==j);
        state_index_row_next=state_index_row(2:end);
        [time_index_row,time_index_col]=find((state_index_row(1:length(state_index_row)-1)-state_index_row_next)~=-1);
        time_index_row=[time_index_row;length(state_index_row_next)];
        time_index_row_next=time_index_row(2:end);
        active_time_horizen=time_index_row_next-time_index_row(1:end-1);
        active_time_horizen=[time_index_row(1);active_time_horizen];
        active_time_data{p1}=sort(active_time_horizen);
        p1=p1+1;
    end
end

State_Limit=[];
State_max_Limit=[];
for i = 1:State_Size
    state_min=active_time_data{i}(ceil(0.05*length(active_time_data{i})));
    state_max=active_time_data{i}(floor(0.95*length(active_time_data{i})));
    State_Limit = [State_Limit; state_min];
    State_max_Limit=[State_max_Limit;state_max];
end
disp('State_Limit done!');


%������С״̬���Ŀռ仮��
% min_state_sequence=always_On_appliance;
% min_state_index=[];
% for i=1:size(cluster_id,1)
%     if(cluster_id(i,:)==min_state_sequence)
%         min_state_index=[min_state_index,i];
%     end
% end
Space_division_strategy=[];



% Ci = lamda * wi�����Ի���Ҫ��wi

% ״̬ת������
Transition_model = {};
W = [];
for i = 1:N
    trans = diag(ones(class_num(i),1)); % ��ʼΪ�ԽǾ��󣬱�ʾͬ״̬���໥ת��
    P_state_temp = cluster_id(:,i);
    P_state_next=P_state_temp(2:end);
    state_change_location=find((P_state_next-P_state_temp(1:end-1))~=0)+1;
    if(class_num(i)>=2)
        for j=1:length(state_change_location)
            p1 =state_change_location(j)-1;
            p2 = state_change_location(j);
            
            if(P_state_temp(p1)==0||P_state_temp(p2)==0)
                continue;
            end
            
            index=find(index_appliance==i);
            T_Window_1=State_Limit(index(P_state_temp(p1)));
            T_Window_2=State_Limit(index(P_state_temp(p2)));
            if(p1-T_Window_1>=0&&p2+T_Window_2<=length(P_state_temp))
                window1 = P_state_temp(p1-T_Window_1+1:p1, :);
                window2 = P_state_temp(p2:p2+T_Window_2-1, :);
                if (all (~(diff(window1))) && all (~(diff(window2))))
                    s1 = P_state_temp(p1);
                    s2 = P_state_temp(p2);
                    trans(s1, s2) = 1; % ���s1״̬��ת����s2״̬
                else
                    if(all (~(diff(window1)))~=1 && all (~(diff(window2)))~=1)
                        window=[window1;window2];
                        window = medfilt1(window);
                        window1=window(1:length(window1));
                        window2=window(length(window1)+1:end);
                    else
                        if(all (~(diff(window1)))~=1)
                            window1 = medfilt1(window1);
                            
                        end
                        if(all (~(diff(window2)))~=1)
                            window2 = medfilt1(window2);
                        end
                    end
                    s1 = window1(end);
                    s2 = window2(1);
                    trans(s1, s2) = 1; % ���s1״̬��ת����s2״̬
                end
            end
        end
        
        
        Transition_model = [Transition_model; trans];
    else
        Transition_model = [Transition_model; 1];
    end
    W = [W; train_rows/length(state_change_location)];
end

Omega = zeros(State_Size, 1);
On_state_num=sparse(State_Size,train_data_num/train_day_num);
On_appliance_num=sparse(N,train_data_num/train_day_num);
p1 = 1;
for i = 1:N
    Omega(p1:p1+class_num(i)-1, :) = W(i, :);
    p1 = p1+class_num(i);
    state_data_interval=reshape(cluster_id(:,i),train_data_num/train_day_num,train_day_num)';
    for t=1:train_data_num/train_day_num
        for j=1:class_num(i)
            [index_location]=find(state_data_interval(:,t)==j);
            if(i==1)
                On_state_num(j,t)=length(index_location);
            else
                On_state_num(sum(class_num(1:i-1))+j,t)=length(index_location);
            end
        end
        if(always_On_appliance(i)==1)
            [index_location]=find(state_data_interval(:,t)>1);
        else
            [index_location]=find(state_data_interval(:,t)>=1);
        end
        On_appliance_num(i,t)=length(index_location);
    end
end
probabilities_On=On_state_num./train_day_num;
proportion_used_applicance=(train_data_num)./(sum(On_state_num,2));

%
On_appliance_num_horizon=sum(On_appliance_num,1);
min_On_appliance_num=min(On_appliance_num_horizon);
[windows_index]=find(On_appliance_num_horizon==min_On_appliance_num);
windows_temp=[1,windows_index+1,train_data_num/train_day_num];

[index_short_horizon]=find(windows_temp(2:end)-windows_temp(1:end-1)<=60);
while(~isempty(index_short_horizon))
    if(index_short_horizon(1)~=length(windows_temp)-1)
        windows_temp(index_short_horizon(1)+1)=[];
    else
        windows_temp(index_short_horizon(1))=[];
    end
    [index_short_horizon]=find(windows_temp(2:end)-windows_temp(1:end-1)<=60);
end
if(test_day_num>1)
    windows_temp_mid=windows_temp(2:end-1);
    for i=1:test_day_num-1
        windows_temp_mid=[windows_temp_mid,windows_temp_mid+i*(train_data_num/train_day_num)];
    end
    windows_temp=[1,windows_temp_mid,test_day_num*(train_data_num/train_day_num)];
end
    windows_index_start=windows_temp(1:end-1);
    windows_index_end=[windows_temp(2:end-1)-1,test_day_num*(train_data_num/train_day_num)];
windows_index=[windows_index_start',windows_index_end'];
    % ��������
end
