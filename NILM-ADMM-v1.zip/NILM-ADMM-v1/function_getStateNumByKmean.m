function [result_Idx]=function_getStateNumByKmean(data_mat,name,index,k)
%FUNCTION_GETSTATENUMBYKMEAN �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
if(index>=1)
    out=[];
    for k = 1:30
        [result_Idx,C,sumD,D] = kmeans(data_mat,k,'dist','sqEuclidean','Replicates',4); %����
        out = [out; [sum(sumD)]];
    end
    figure(index);
    plot(out);
    title(name);
    xlabel('k');
    ylabel('gap');
else
    if(isempty(k))
        disp('cluster num is empty!');
    else
        [result_Idx,C,sumD,D] = kmeans(data_mat,k,'dist','sqEuclidean','Replicates',4);
        cluster_Idx=result_Idx;
        for i=1:k
            C_sort=sort(C);
            index_row=find(C==C_sort(i)); 
                index_cluter=find(result_Idx==index_row);
                cluster_Idx(index_cluter)=i;            
        end
        result_Idx=cluster_Idx;
    end
end
end

